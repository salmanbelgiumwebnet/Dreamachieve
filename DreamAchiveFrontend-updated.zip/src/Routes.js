import React from 'react';
import { Switch, Route } from 'react-router';
import About from './component/about/About';
import BlogsDetails from './component/blogs-details/BlogsDetails';
import Blogs from './component/blogs/Blogs';
import Contact from './component/contact/Contact';
import Faq from './component/faq/Faq';
import Home from './component/home/Home';
import Podcast from './component/Podcast/Podcast';
import Privacy from './component/privacy/Privacy';
import Programs from './component/programs/Programs';
import ProgramsTwo from './component/programs/ProgramsTwo';
import Video from './component/video/Video';
import TermsAndConditions from './component/termsandconditions/TermsAndConditions';
import Shop from './component/shop/Shop';
import CoursesVideo from './component/courses-video/CoursesVideo';
import CoursesAllVideo from './component/courses-video/CoursesAllVideo';
import ProductDetails from './component/product-details/ProductDetails';
import Cart from './component/cart/Cart';
import CheckoutForm from './component/checkout/CheckoutForm';
import Events from './component/events/Events';
import CoursesCategory from './component/dreamachieve-courses/courses-category/CoursesCategory';
import CoursesContent from './component/dreamachieve-courses/courses-content/CoursesContent';
import PodcastAudio from './component/Podcast/PodcastAudio';


function Routes(){
    return(
        <>
         
            <Switch>
                {/* <Route path="*" component={Home}></Route>   */}
                <Route exact path="/" component={Home}></Route>
                <Route path="/about" component={About}></Route>
                <Route path="/blogs" component={Blogs}></Route>
                <Route path="/blogs-details" component={BlogsDetails}></Route>
                <Route path="/podcast" component={Podcast}></Route>
                <Route path="/contact" component={Contact}></Route>
                <Route path="/video" component={Video}></Route>
                <Route path="/Programs" component={Programs}></Route>
                <Route path="/Programs-two" component={ProgramsTwo}></Route>
                <Route path="/faq" component={Faq}></Route>
                <Route path="/privacy" component={Privacy}></Route>  
                <Route path="/termsandcondition" component={TermsAndConditions}></Route>
                <Route path="/shop" component={Shop}></Route>
                <Route path="/courses-video" component={CoursesVideo}></Route>
                <Route path="/courses-all-video" component={CoursesAllVideo}></Route> 
                <Route path="/product-details" component={ProductDetails}></Route>
                <Route path="/cart" component={Cart}></Route>
                <Route path="/checkout-form" component={CheckoutForm}></Route>
                <Route path="/events" component={Events}></Route>
                <Route path="/courses-category" component={CoursesCategory}></Route>
                <Route path="/courses-content" component={CoursesContent}></Route>
                <Route path="/podcast-audio" component={PodcastAudio}></Route>                                       

            </Switch>
        </> 
    )
}



export default Routes