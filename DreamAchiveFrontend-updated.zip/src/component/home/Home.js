import React, { useState, useEffect } from "react";
import { Col, Container, Row } from "react-bootstrap";
import Header from "../navbar/Header";
import { Link } from "react-router-dom";
import Footer from "../footer/Footer";
import { Tab, Tabs, TabList, TabPanel } from 'react-tabs';
import 'react-tabs/style/react-tabs.css';
import ModalVideo from 'react-modal-video'
import ContentLoader, { Facebook } from 'react-content-loader'
import { AnimateOnChange } from 'react-animation'

import AOS from 'aos';
import 'aos/dist/aos.css' ;

import environment from '../base/baseUrl'
import axios from 'axios';
import Swal from "sweetalert2";

function Home() {

    var BASE_URL = environment.BASE_URL;

    const [isOpen, setOpen] = useState(false)
    const [home, setHome] = useState([])
    const [socialaccount, setSocialAccount] = useState([])
    const [upcomingevents, setUpcomingevents] = useState([])
    const [latestblog, setLatestblog] = useState([])

    useEffect(() => {
        AOS.init({
          duration : 1000
        });
      }, []);
      
    useEffect(() => {
        axios
            .get(BASE_URL + '/home')
            .then(res => {
                setHome(res.data)
                console.clear();
                console.log(res.data)
            }).catch(err => {
                console.log(err)
            })
        axios
            .get(BASE_URL + '/socialaccount')
            .then(res => {
                setSocialAccount(res.data)
                console.log(res.data)
            }).catch(err => {
                console.log(err)
            })
        axios
            .get(BASE_URL + '/upcomingevents')
            .then(res => {
                setUpcomingevents(res.data)
                console.log(res.data)
            }).catch(err => {
                console.log(err)
            })
        axios
            .get(BASE_URL + '/getlatestblog')
            .then(res => {
                setLatestblog(res.data)
                console.log(res.data)
            }).catch(err => {
                console.log(err)
            })
    }, [])

    function Subscribe() {

        var email = document.getElementById('email').value;
        var jsonInput = {
            email: email
        }
        axios.post(BASE_URL + 'subscribe', jsonInput).then(res => {
            Swal.fire({
                title: 'Success',
                type: 'success',
                text: 'Suscribe Successfully.',
            });
            window.location.reload();
        }).catch(err => {
            Swal.fire({
                icon: 'error',
                title: 'Oops...',
                text: 'Error Occured !',
            });
        })
    }

    

    return (

        <>

            {/*====== HEADER PART START ======*/}
            <Header />
            {/*====== HEADER PART ENDS ======*/}

            {/*====== banner PART start ======*/}
            <div id="parallax" className="header-content d-flex align-items-center">

                <div className="container">
                    <div className="row align-items-center" >
                        <div className="col-xl-6 col-lg-6">
                   
                            <div className="header-content-right" data-aos="fade-up">
                                <h4 className="sub-title"> <span> I’m </span> Nádia Tavares! </h4>
                                <h1 className="title">Your Health Coach</h1>
                                <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit,
                                    sed do eiusmod tempor incididunt ut labore et dolore magna aliqua.
                                    Ut enim ad minim veniam,</p>
                                <a className="main-btn-border" href="#work"> Get Appointment  </a>
                                <a className="main-btn" href="#work"> Join Us</a>

                                <div className="header-social">
                                    <div className="header-social-icon">
                                        <ul>
                                            <li><a href="#"><i className="lni-instagram-filled" /></a></li>
                                            <li><a href="#"><i className="lni-facebook-filled" /></a></li>
                                            <li><a href="#"><i className="lni-twitter-original" /></a></li>
                                            {/* <li><a href="#"><i className="lni-youtube-filled" /></a></li> */}
                                        </ul>
                                    </div> {/* header social */}

                                </div>

                            </div> 
                            {/* header content right */}
                        

                        </div>
                        <div className="col-lg-5 offset-xl-1">
                 

                            <div className="header-image d-none d-lg-block" data-aos="fade-up">
                                <img src="assets/images/banner/banner-img.png" alt="hero" />
                            </div> {/* header image */}
                         
                           
                        </div>
                    </div> {/* row */}
                </div> {/* container */}

            </div>
            {/*====== Banner PART End ======*/}

            {/*====== Boxes PART Start ======*/}
            <section className="hm-section-2">
                <Container>
                    <Row>

                 
                         <Col md="3" xs="12" >
                       
                            <div className="sec-2-boxes" data-aos="fade-up">
                                <div className="sec-2-boxes-icn">
                                    <img src="assets/images/icons/bag.jpg" />
                                </div>
                                <div className="sec-2-boxes-content">
                                    <h6> Lorem ipsum  </h6>
                                    <p>Lorem Ipsum is simply dummy text of the printing and typesetting industry.</p>

                                    <button className="sec-2-boxe-btn"> <i class="fas fa-chevron-right"></i> </button>

                                </div>
                            </div>
                        
                            
                            </Col>
                           
                            <Col md="3" xs="12" data-aos="fade-up">
                            <div className="sec-2-boxes">
                                <div className="sec-2-boxes-icn">
                                    <img src="assets/images/icons/idea.jpg" />
                                </div>
                                <div className="sec-2-boxes-content">
                                    <h6> Lorem ipsum  </h6>
                                    <p>Lorem Ipsum is simply dummy text of the printing and typesetting industry.</p>

                                    <button className="sec-2-boxe-btn"> <i class="fas fa-chevron-right"></i> </button>

                                </div>
                            </div>
                            </Col>

                            <Col md="3" xs="12">
                            <div className="sec-2-boxes" data-aos="fade-up">
                                <div className="sec-2-boxes-icn">
                                    <img src="assets/images/icons/yt.jpg" />
                                </div>
                                <div className="sec-2-boxes-content">
                                    <h6> Lorem ipsum  </h6>
                                    <p>Lorem Ipsum is simply dummy text of the printing and typesetting industry.</p>

                                    <button className="sec-2-boxe-btn"> <i class="fas fa-chevron-right"></i> </button>

                                </div>
                            </div>
                            </Col>

                            <Col md="3" xs="12">
                            <div className="sec-2-boxes" data-aos="fade-up">
                                <div className="sec-2-boxes-icn">
                                    <img src="assets/images/icons/earth.jpg" />
                                </div>
                                <div className="sec-2-boxes-content">
                                    <h6> Lorem ipsum  </h6>
                                    <p>Lorem Ipsum is simply dummy text of the printing and typesetting industry.</p>

                                    <button className="sec-2-boxe-btn"> <i class="fas fa-chevron-right"></i> </button>

                                </div>
                            </div>
                            </Col>
                    
                       

                    </Row>
                </Container>
            </section>
            {/*====== Boxes PART End ======*/}

            {/*====== About PART Start ======*/}
            <section className="hm-section-2">
                <Container>
                    <Row>
                        
                        <Col md="6" xs="12">
                            
                            <div className="abt-left-d" data-aos="fade-up-right">
                                <div className="abt-img-d-1">
                                    <img src="assets/images/provide.jpg" />
                                </div>

                                <div className="abt-img-d-2">
                                    <img src="assets/images/banner/banner-img.png" />
                                </div>

                            </div>
                        </Col>
                        

                        <Col md="6" xs="12">

                         
                            <div className="abt-right-d" data-aos="fade-up-left">
                                <div className="abt-right-d-1">
                                    <h6> WHAT WE PROVIDE </h6>
                                    <h3>Lorem ipsum dollar site ameat dummy text</h3>
                                    <p> Lorem ipsum dolor sit amet, consectetur adipiscing elit,
                                        sed do eiusmod tempor incididunt ut labore et dolore magna aliqua.</p>
                                </div>
                                <div className="abt-right-d-content-d1">
                                    <div className="abt-right-d-content-d1-img">
                                        <img src="https://via.placeholder.com/150" />
                                    </div>
                                    <div className="abt-right-d-content-d2-text">
                                        <h5> Lorem ipsum dollar </h5>
                                        <p> Lorem ipsum dolor sit amet, consectetur adipiscing elit, </p>
                                    </div>
                                </div>

                                <div className="abt-right-d-content-d1">
                                    <div className="abt-right-d-content-d1-img">
                                        <img src="https://via.placeholder.com/150" />
                                    </div>
                                    <div className="abt-right-d-content-d2-text">
                                        <h5> Lorem ipsum dollar </h5>
                                        <p> Lorem ipsum dolor sit amet, consectetur adipiscing elit, </p>
                                    </div>
                                </div>

                                <div className="abt-btn-d">
                                    <button className="main-btn"> Learn More </button>
                                </div>
                            </div>


                            
                        </Col>


                    </Row>
                </Container>
            </section>
            {/*====== About PART End ======*/}

            {/*====== SERVICES PART START ======*/}
            <section id="service" className="services-area gray-bg pt-60 pb-60">
                <div className="container">
                    <div className="row justify-content-center">
                        <div className="col-lg-8">
                            <div className="section-title text-center pb-30">
                                <h2 className="mb-2">Lorem ipsum dollar</h2>
                                <p>Nunc id dui at sapien faucibus fermentum ut vel diam. Nullam tempus, nunc id efficitur sagittis, urna est ultricies eros, ac porta sem turpis quis leo.</p>
                            </div> {/* section title */}
                        </div>
                    </div> {/* row */}
                    <div className="row justify-content-center" >
                        <div className="col-lg-4 col-md-6 col-sm-8">
                            <div className="single-service text-center mt-30" data-aos="fade-up">
                                <div className="service-icon">
                                    <i className="lni-code-alt" />
                                </div>
                                <div className="service-content">
                                    <h4 className="service-title"><a href="#">Lorem ipsum</a></h4>
                                    <p>Curabitur vitae magna felis. Nulla ac libero ornare, vestibulum lacus quis blandit enimdicta sunt.</p>
                                    <button className="circle-icn-btn"> <i class="fas fa-long-arrow-alt-right"></i> </button>
                                </div>
                            </div> {/* single service */}
                        </div>
                        <div className="col-lg-4 col-md-6 col-sm-8">
                            <div className="single-service text-center mt-30" data-aos="fade-up">
                                <div className="service-icon">
                                    <i className="lni-color-pallet" />
                                </div>
                                <div className="service-content">
                                    <h4 className="service-title"><a href="#contact">Lorem ipsum</a></h4>
                                    <p>Curabitur vitae magna felis. Nulla ac libero ornare, vestibulum lacus quis blandit enimdicta sunt.</p>
                                    <button className="circle-icn-btn"> <i class="fas fa-long-arrow-alt-right"></i> </button>
                                </div>
                            </div> {/* single service */}
                        </div>
                        <div className="col-lg-4 col-md-6 col-sm-8">
                            <div className="single-service text-center mt-30" data-aos="fade-up">
                                <div className="service-icon">
                                    <i className="lni-mobile" />
                                </div>
                                <div className="service-content">
                                    <h4 className="service-title"><a href="#">Lorem ipsum</a></h4>
                                    <p>Curabitur vitae magna felis. Nulla ac libero ornare, vestibulum lacus quis blandit enimdicta sunt.</p>
                                    <button className="circle-icn-btn"> <i class="fas fa-long-arrow-alt-right"></i> </button>

                                </div>
                            </div> {/* single service */}
                        </div>
                        <div className="col-lg-4 col-md-6 col-sm-8">
                            <div className="single-service text-center mt-30" data-aos="fade-up">
                                <div className="service-icon">
                                    <i className="lni-vector" />
                                </div>
                                <div className="service-content">
                                    <h4 className="service-title"><a href="#">Lorem ipsum</a></h4>
                                    <p>Curabitur vitae magna felis. Nulla ac libero ornare, vestibulum lacus quis blandit enimdicta sunt.</p>
                                    <button className="circle-icn-btn"> <i class="fas fa-long-arrow-alt-right"></i> </button>

                                </div>
                            </div> {/* single service */}
                        </div>
                        <div className="col-lg-4 col-md-6 col-sm-8">
                            <div className="single-service text-center mt-30" data-aos="fade-up">
                                <div className="service-icon">
                                    <i className="lni-website" />
                                </div>
                                <div className="service-content">
                                    <h4 className="service-title"><a href="#">Lorem ipsum</a></h4>
                                    <p>Curabitur vitae magna felis. Nulla ac libero ornare, vestibulum lacus quis blandit enimdicta sunt.</p>
                                    <button className="circle-icn-btn"> <i class="fas fa-long-arrow-alt-right"></i> </button>

                                </div>
                            </div> {/* single service */}
                        </div>
                        <div className="col-lg-4 col-md-6 col-sm-8">
                            <div className="single-service text-center mt-30" data-aos="fade-up">
                                <div className="service-icon">
                                    <i className="lni-support" />
                                </div>
                                <div className="service-content">
                                    <h4 className="service-title"><a href="#">Lorem ipsum</a></h4>
                                    <p>Curabitur vitae magna felis. Nulla ac libero ornare, vestibulum lacus quis blandit enimdicta sunt.</p>
                                    <button className="circle-icn-btn"> <i class="fas fa-long-arrow-alt-right"></i> </button>

                                </div>
                            </div> {/* single service */}
                        </div>
                    </div> {/* row */}
                </div> {/* container */}
            </section>
            {/*====== SERVICES PART ENDS ======*/}

            {/*====== Video PART START ======*/}
            <section className="video-section">
                <Container>
                    <Row>
                        <Col md="12" xs="12">
                            <div className="video-title">
                                <h2> We Provide Life-Changing Video Tutorials  </h2>
                            </div>
                        </Col>

                        <Col md="12" xs="12">
                            <div className="video-tabs-main-d">
                                <Tabs>
                                    <TabList className="tab-menu">
                                        <Tab>All</Tab>
                                        <Tab>Title 1</Tab>
                                        <Tab>Title 2</Tab>
                                        <Tab>Title 3</Tab>
                                        <Tab>Title 4</Tab>
                                    </TabList>

                                    <TabPanel>
                                        <Row>
                                            <Col md="4" xs="12">
                                                <div className="video-box" data-aos="fade-up">
                                                    <div className="video-btn-icn" onClick={() => setOpen(true)}>
                                                        <i class="fa fa-play" aria-hidden="true"></i>
                                                    </div>
                                                    <div className="video-text">
                                                        <h6> Lorem ipsum dollar </h6>
                                                        <p> By lorem ipsum </p>
                                                    </div>
                                                </div>
                                            </Col>

                                            <Col md="4" xs="12">
                                                <div className="video-box" data-aos="fade-up">
                                                    <div className="video-btn-icn" onClick={() => setOpen(true)}>
                                                        <i class="fa fa-play" aria-hidden="true"></i>
                                                    </div>
                                                    <div className="video-text">
                                                        <h6> Lorem ipsum dollar </h6>
                                                        <p> By lorem ipsum </p>
                                                    </div>
                                                </div>
                                            </Col>

                                            <Col md="4" xs="12">
                                                <div className="video-box" data-aos="fade-up">
                                                    <div className="video-btn-icn" onClick={() => setOpen(true)}>
                                                        <i class="fa fa-play" aria-hidden="true"></i>
                                                    </div>
                                                    <div className="video-text">
                                                        <h6> Lorem ipsum dollar </h6>
                                                        <p> By lorem ipsum </p>
                                                    </div>
                                                </div>
                                            </Col>

                                        </Row>

                                        <Row className="mt-4">
                                            <Col md="3" xs="12">
                                                <div className="video-box" data-aos="fade-up">
                                                    <div className="video-btn-icn" onClick={() => setOpen(true)}>
                                                        <i class="fa fa-play" aria-hidden="true"></i>
                                                    </div>
                                                    <div className="video-text">
                                                        <h6> Lorem ipsum dollar </h6>
                                                        <p> By lorem ipsum </p>
                                                    </div>
                                                </div>
                                            </Col>

                                            <Col md="3" xs="12">
                                                <div className="video-box" data-aos="fade-up">
                                                    <div className="video-btn-icn" onClick={() => setOpen(true)}>
                                                        <i class="fa fa-play" aria-hidden="true"></i>
                                                    </div>
                                                    <div className="video-text">
                                                        <h6> Lorem ipsum dollar </h6>
                                                        <p> By lorem ipsum </p>
                                                    </div>
                                                </div>
                                            </Col>

                                            <Col md="3" xs="12">
                                                <div className="video-box" data-aos="fade-up">
                                                    <div className="video-btn-icn" onClick={() => setOpen(true)}>
                                                        <i class="fa fa-play" aria-hidden="true"></i>
                                                    </div>
                                                    <div className="video-text">
                                                        <h6> Lorem ipsum dollar </h6>
                                                        <p> By lorem ipsum </p>
                                                    </div>
                                                </div>
                                            </Col>

                                            <Col md="3" xs="12">
                                                <div className="video-box" data-aos="fade-up">
                                                    <div className="video-btn-icn" onClick={() => setOpen(true)}>
                                                        <i class="fa fa-play" aria-hidden="true"></i>
                                                    </div>
                                                    <div className="video-text">
                                                        <h6> Lorem ipsum dollar </h6>
                                                        <p> By lorem ipsum </p>
                                                    </div>
                                                </div>
                                            </Col>

                                        </Row>



                                    </TabPanel>
                                    <TabPanel>
                                        <Row>
                                            <Col md="4" xs="12">
                                                <div className="video-box" data-aos="fade-up">
                                                    <div className="video-btn-icn" onClick={() => setOpen(true)}>
                                                        <i class="fa fa-play" aria-hidden="true"></i>
                                                    </div>
                                                    <div className="video-text">
                                                        <h6> Lorem ipsum dollar </h6>
                                                        <p> By lorem ipsum </p>
                                                    </div>
                                                </div>
                                            </Col>
                                        </Row>

                                    </TabPanel>
                                    <TabPanel>
                                        <Row>
                                            <Col md="4" xs="12">
                                                <div className="video-box" data-aos="fade-up">
                                                    <div className="video-btn-icn" onClick={() => setOpen(true)}>
                                                        <i class="fa fa-play" aria-hidden="true"></i>
                                                    </div>
                                                    <div className="video-text">
                                                        <h6> Lorem ipsum dollar </h6>
                                                        <p> By lorem ipsum </p>
                                                    </div>
                                                </div>
                                            </Col>
                                        </Row>
                                    </TabPanel>
                                    <TabPanel>
                                        <Row>
                                            <Col md="4" xs="12">
                                                <div className="video-box" data-aos="fade-up">
                                                    <div className="video-btn-icn" onClick={() => setOpen(true)}>
                                                        <i class="fa fa-play" aria-hidden="true"></i>
                                                    </div>
                                                    <div className="video-text">
                                                        <h6> Lorem ipsum dollar </h6>
                                                        <p> By lorem ipsum </p>
                                                    </div>
                                                </div>
                                            </Col>
                                        </Row>
                                    </TabPanel>
                                    <TabPanel>
                                        <Row>
                                            <Col md="4" xs="12">
                                                <div className="video-box" data-aos="fade-up">
                                                    <div className="video-btn-icn" onClick={() => setOpen(true)}>
                                                        <i class="fa fa-play" aria-hidden="true"></i>
                                                    </div>
                                                    <div className="video-text">
                                                        <h6> Lorem ipsum dollar </h6>
                                                        <p> By lorem ipsum </p>
                                                    </div>
                                                </div>
                                            </Col>
                                        </Row>
                                    </TabPanel>

                                </Tabs>


                            </div>
                        </Col>
                    </Row>
                </Container>
            </section>
            {/*====== Video PART END ======*/}

            {/*====== NEWSLETTER PART START ======*/}
            <section className="newsletter-section">
                <Container>
                    <Row>
                        <Col md="12" xs="12">
                            <div className="newsletter-main-d" data-aos="fade-up">
                                <p>OUR NEWSLETTER</p>
                                <h3>Get More Every Single Update To Join Our Newsletters</h3>
                                <div className="news-input-d">
                                    <input type="email" id ="email" className="form-control" placeholder="enter your email" />
                                    <button onClick={() => Subscribe()} className="news-btn">
                                        Subscribe Now
                                    </button>
                                </div>
                            </div>
                        </Col>
                    </Row>
                </Container>
            </section>
            {/*====== NEWSLETTER PART END ======*/}


            <section id="work" className="work-area pt-60 pb-60">
                <div className="container">
                <div className="row">
                    <div className="col-lg-8">
                    <div className="section-title pb-25">
                        <h2 className="title">Recent Products</h2>
                        <p>Nunc id dui at sapien faucibus fermentum ut vel diam. Nullam tempus, nunc id efficitur sagittis, urna est ultricies eros, ac porta sem turpis quis leo.</p>
                    </div> {/* section title */}
                    </div>
                </div> {/* row */}
                <div className="row">
                <div className="col-lg-4 col-md-6 col-sm-6">
                                    <div className="single-work text-center mt-30" data-aos="fade-up">
                                        <div className="work-image">
                                        <img src="https://images.pexels.com/photos/1082528/pexels-photo-1082528.jpeg?auto=compress&cs=tinysrgb&dpr=2&h=650&w=940" alt="work" />
                                        </div>
                                        <div className="work-overlay">
                                        <div className="work-content">
                                            <h3 className="work-title">Product Design</h3>
                                            <ul>
                                            <li><a className="image-popup" href="assets/images/work/w-6.jpg"><i className="lni-cart" /></a></li>
                                            <li><Link to="/shop-details"><i className="lni-eye" /></Link></li>
                                            </ul>
                                        </div>
                                        </div>
                                        <div className="work-overlay-price">
                                            <p> $60.00 </p>
                                        </div>  
                                    </div> {/* single work */}
                                </div>
                                <div className="col-lg-4 col-md-6 col-sm-6">
                                    <div className="single-work text-center mt-30" data-aos="fade-up">
                                        <div className="work-image">
                                        <img src="https://images.pexels.com/photos/45982/pexels-photo-45982.jpeg?auto=compress&cs=tinysrgb&dpr=2&h=650&w=940" alt="work" />
                                        </div>
                                        <div className="work-overlay">
                                        <div className="work-content">
                                            <h3 className="work-title">Product Design</h3>
                                            <ul>
                                            <li><a className="image-popup" href="assets/images/work/w-6.jpg"><i className="lni-cart" /></a></li>
                                            <li><Link to="/shop-details"><i className="lni-eye" /></Link></li>
                                            </ul>
                                        </div>
                                        </div>
                                        <div className="work-overlay-price">
                                            <p> $60.00 </p>
                                        </div>  
                                    </div> {/* single work */}
                                </div>
                                <div className="col-lg-4 col-md-6 col-sm-6">
                                    <div className="single-work text-center mt-30" data-aos="fade-up">
                                        <div className="work-image">
                                        <img src="https://images.pexels.com/photos/1082528/pexels-photo-1082528.jpeg?auto=compress&cs=tinysrgb&dpr=2&h=650&w=940" alt="work" />
                                        </div>
                                        <div className="work-overlay">
                                        <div className="work-content">
                                            <h3 className="work-title">Product Design</h3>
                                            <ul>
                                            <li><a className="image-popup" href="assets/images/work/w-6.jpg"><i className="lni-cart" /></a></li>
                                            <li><Link to="/shop-details"><i className="lni-eye" /></Link></li>
                                            </ul>
                                        </div>
                                        </div>
                                        <div className="work-overlay-price">
                                            <p> $60.00 </p>
                                        </div>  
                                    </div> {/* single work */}
                                </div>
                                <div className="col-lg-4 col-md-6 col-sm-6">
                                    <div className="single-work text-center mt-30" data-aos="fade-up">
                                        <div className="work-image">
                                        <img src="https://images.pexels.com/photos/45982/pexels-photo-45982.jpeg?auto=compress&cs=tinysrgb&dpr=2&h=650&w=940" alt="work" />
                                        </div>
                                        <div className="work-overlay">
                                        <div className="work-content">
                                            <h3 className="work-title">Product Design</h3>
                                            <ul>
                                            <li><a className="image-popup" href="assets/images/work/w-6.jpg"><i className="lni-cart" /></a></li>
                                            <li><Link to="/shop-details"><i className="lni-eye" /></Link></li>
                                            </ul>
                                        </div>
                                        </div>
                                        <div className="work-overlay-price">
                                            <p> $60.00 </p>
                                        </div>  
                                    </div> {/* single work */}
                                </div>
                                <div className="col-lg-4 col-md-6 col-sm-6">
                                    <div className="single-work text-center mt-30" data-aos="fade-up">
                                        <div className="work-image">
                                        <img src="https://images.pexels.com/photos/1082528/pexels-photo-1082528.jpeg?auto=compress&cs=tinysrgb&dpr=2&h=650&w=940" alt="work" />
                                        </div>
                                        <div className="work-overlay">
                                        <div className="work-content">
                                            <h3 className="work-title">Product Design</h3>
                                            <ul>
                                            <li><a className="image-popup" href="assets/images/work/w-6.jpg"><i className="lni-cart" /></a></li>
                                            <li><Link to="/shop-details"><i className="lni-eye" /></Link></li>
                                            </ul>
                                        </div>
                                        </div>
                                        <div className="work-overlay-price">
                                            <p> $60.00 </p>
                                        </div>  
                                    </div> {/* single work */}
                                </div>
                                <div className="col-lg-4 col-md-6 col-sm-6">
                                    <div className="single-work text-center mt-30" data-aos="fade-up" >
                                        <div className="work-image">
                                        <img src="https://images.pexels.com/photos/45982/pexels-photo-45982.jpeg?auto=compress&cs=tinysrgb&dpr=2&h=650&w=940" alt="work" />
                                        </div>
                                        <div className="work-overlay">
                                        <div className="work-content">
                                            <h3 className="work-title">Product Design</h3>
                                            <ul>
                                            <li><a className="image-popup" href="assets/images/work/w-6.jpg"><i className="lni-cart" /></a></li>
                                            <li><Link to="/shop-details"><i className="lni-eye" /></Link></li>
                                            </ul>
                                        </div>
                                        </div>
                                        <div className="work-overlay-price">
                                            <p> $60.00 </p>
                                        </div>  
                                    </div> {/* single work */}
                                </div>
                </div> {/* row */}
                <div className="row">
                    <div className="col-lg-12">
                    <div className="work-more text-center mt-50" data-aos="fade-up">
                        <a className="main-btn" href="#">More Products</a>
                    </div> {/* work more */}
                    </div>
                </div> {/* row */}
                </div> {/* container */}
            </section>

            {/*====== EVENTS PART START ======*/}
            <section className="events-section">
                <Container>
                    <Row>
                        <Col md="12" xs="12">
                            <div className="events-title">
                                <h2> Upcoming Events </h2>
                            </div>
                        </Col>
                    </Row>

                    <Row>
                        <Col lg="10 m-auto" md="12" xs="12">
                            <div className="event-box-main" data-aos="fade-up">
                                <div className="event-b-1">
                                    <img src="https://via.placeholder.com/400x350" />
                                </div>
                                <div className="event-text-d">
                                    <p className="address-p"> january 24, 2021 12:00am. New York USA </p>
                                    <h4> Lorem ipsum dollar site ameat dummy text.</h4>
                                    <p className="event-text"> Curabitur vitae magna felis. Nulla ac libero ornare, vestibulum lacus quis blandit enimdicta sunt. </p>
                                    <button className="main-btn"> Learn more</button>
                                </div>
                            </div>
                        </Col>
                    </Row>

                    <Row>
                        <Col lg="10 m-auto" md="12" xs="12">
                            <div className="event-item-box-main" data-aos="fade-up">
                                <div className="event-item-d-1">
                                    <div className="event-date"> <h2> 21 Jan </h2> </div>
                                    <div className="event-d-1-text">
                                        <p className="event-lbl"> New york, USA  </p>
                                        <h4> Lorem ipsum dollar site ameat dummy text </h4>
                                    </div>
                                </div>

                                <div className="event-btn-d">
                                    <Link to=""> Learn more <i class="fas fa-long-arrow-alt-right"></i> </Link>
                                </div>
                            </div>
                        </Col>

                        <Col lg="10 m-auto" md="12" xs="12">
                            <div className="event-item-box-main" data-aos="fade-up">
                                <div className="event-item-d-1">
                                    <div className="event-date"> <h2> 23 Jan </h2> </div>
                                    <div className="event-d-1-text">
                                        <p className="event-lbl"> New york, USA  </p>
                                        <h4> Lorem ipsum dollar site ameat dummy text </h4>
                                    </div>
                                </div>

                                <div className="event-btn-d">
                                    <Link to=""> Learn more <i class="fas fa-long-arrow-alt-right"></i> </Link>
                                </div>
                            </div>
                        </Col>
                        <Col md="12">
                            <div className="event-view-all">
                                <Link to="/events" data-aos="fade-up"> View All <i class="fas fa-long-arrow-alt-right"></i></Link>
                            </div>
                        </Col>
                    </Row>
                </Container>
            </section>
            {/*====== EVENTS PART END ======*/}

            {/*====== BLOGS PART START ======*/}
            <section className="blogs-section">
                <Container>
                    <Row>
                        <Col md="12" xs="12">
                            <div className="blogs-title">
                                <h2> Our Latest Blogs </h2>
                                <p> Lorem Ipsum is simply dummy text of the printing and typesetting industry. </p>
                            </div>
                        </Col>
                    </Row>

                    <Row>
                        <Col md="4" xs="12">
                            <div className="blog-box" data-aos="fade-up">
                                <div className="blog-img">
                                    <img src="assets/images/events.jpg" />
                                </div>
                                <div className="blog-text-d">
                                    <Link to=""> <h5> Coach Cerftification Programas Most Powerful Coach </h5> </Link>
                                    <p>
                                        Lorem Ipsum is simply dummy text of the printing
                                        and typesetting industry  Lorem Ipsum is simply dummy text of the printing and
                                    </p>
                                    <button className="blog-btn" > View More </button>
                                </div>
                            </div>
                        </Col>

                        <Col md="4" xs="12">
                            <div className="blog-box" data-aos="fade-up">
                                <div className="blog-img">
                                    <img src="https://via.placeholder.com/400x280" />
                                </div>
                                <div className="blog-text-d">
                                    <Link to=""> <h5> Coach Cerftification Programas Most Powerful Coach </h5> </Link>
                                    <p>
                                        Lorem Ipsum is simply dummy text of the printing
                                        and typesetting industry  Lorem Ipsum is simply dummy text of the printing and
                                    </p>
                                    <button className="blog-btn"> View More </button>
                                </div>
                            </div>
                        </Col>
                        <Col md="4" xs="12">
                            <div className="blog-box" data-aos="fade-up">
                                <div className="blog-img">
                                    <img src="https://via.placeholder.com/400x280" />
                                </div>
                                <div className="blog-text-d">
                                    <Link to=""> <h5> Coach Cerftification Programas Most Powerful Coach </h5> </Link>
                                    <p>
                                        Lorem Ipsum is simply dummy text of the printing
                                        and typesetting industry  Lorem Ipsum is simply dummy text of the printing and
                                    </p>
                                    <button className="blog-btn"> View More </button>
                                </div>
                            </div>
                        </Col>
                    </Row>

                    <Row>
                        <Col lg="12" xs="12">
                            <div className="blog-more text-center mt-50">
                                <a className="main-btn" href="#" data-aos="fade-up">More posts</a>
                            </div> {/* blog more */}
                        </Col>
                    </Row>
                </Container>
            </section>
            {/*====== BLOGS PART END ======*/}
            
            {/*====== FOOTER PART START ======*/}
            <Footer />
            {/*====== FOOTER PART END ======*/}

            <ModalVideo channel='youtube' autoplay isOpen={isOpen} videoId="77ZozI0rw7w" onClose={() => setOpen(false)} />



        </>
    );
}




export default Home