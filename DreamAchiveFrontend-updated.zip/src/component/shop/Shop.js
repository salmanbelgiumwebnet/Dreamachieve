import React,{useState} from "react";
import { Col, Container, Pagination, Row } from "react-bootstrap";
import Header from "../navbar/Header";
import { Link } from "react-router-dom";
import Footer from "../footer/Footer";
import { Tab, Tabs, TabList, TabPanel, } from 'react-tabs';
import 'react-tabs/style/react-tabs.css';
import ModalVideo from 'react-modal-video'
import ContentLoader, { Facebook } from 'react-content-loader'
import { RiShoppingCartFill } from 'react-icons/ri';
import AOS from 'aos';
import 'aos/dist/aos.css' ;


function Shop(props){
    const [isOpen, setOpen] = useState(false)
    return(

        <>
      
            {/*====== HEADER PART START ======*/}
                <Header/>
            {/*====== HEADER PART ENDS ======*/}

            {/*====== banner PART start ======*/}
            <section className="hero-banner-section">
                <Container>
                    <Row>
                        <Col md="12" xs="12">
                            <div className="hero-content">
                                <div className="cd-main"> 
                                    <h5> Store </h5> 
                                    <ul> 
                                        <li>   <Link to="/" className=""> Home </Link> </li>
                                        <li> <Link to="/video" className="active"> Store </Link>  </li>
                                      </ul>
                                </div>
                                
                            </div>
                        </Col>
                    </Row>
                </Container>
            </section>
            {/*====== Banner PART End ======*/}

            {/*====== BLOG PART START ======*/}
            <section className="blogs-section blogs-main"> 
                <Container>
                    <Row>
                        <Col md="12" xs="12">
                            <div className="section-title prod-title">
                                <div>
                                    <h2 className="title">Products </h2>
                                </div>
                                <div>
                                    <button className="cart-flex"> <Link to="/cart">  <RiShoppingCartFill /> 2 </Link> </button>
                                </div>
                            </div> 
                        </Col>
                    </Row>

                    <Row>
                        <div className="col-lg-4 col-md-6 col-sm-6">
                            <div className="single-work text-center mt-30">
                                <div className="work-image">
                                <img src="https://images.pexels.com/photos/1082528/pexels-photo-1082528.jpeg?auto=compress&cs=tinysrgb&dpr=2&h=650&w=940" alt="work" />
                                </div>
                                <div className="work-overlay">
                                <div className="work-content">
                                    <h3 className="work-title">Product Design</h3>
                                    <ul>
                                    <li><a className="image-popup" href="assets/images/work/w-6.jpg"><i className="lni-cart" /></a></li>
                                    <li><Link to="/product-details"><i className="lni-eye" /></Link></li>
                                    </ul>
                                </div>
                                </div>
                                <div className="work-overlay-price">
                                    <p> $60.00 </p>
                                </div>  
                            </div> {/* single work */}
                        </div>
                        
                        <div className="col-lg-4 col-md-6 col-sm-6">
                            <div className="single-work text-center mt-30">
                                <div className="work-image">
                                <img src="https://images.pexels.com/photos/45982/pexels-photo-45982.jpeg?auto=compress&cs=tinysrgb&dpr=2&h=650&w=940" alt="work" />
                                </div>
                                <div className="work-overlay">
                                <div className="work-content">
                                    <h3 className="work-title">Product Design</h3>
                                    <ul>
                                    <li><a className="image-popup" href="assets/images/work/w-6.jpg"><i className="lni-cart" /></a></li>
                                    <li><Link to="/product-details"><i className="lni-eye" /></Link></li>
                                    </ul>
                                </div>
                                </div>
                                <div className="work-overlay-price">
                                    <p> $60.00 </p>
                                </div>  
                            </div> {/* single work */}
                        </div>
                        <div className="col-lg-4 col-md-6 col-sm-6">
                            <div className="single-work text-center mt-30">
                                <div className="work-image">
                                <img src="https://images.pexels.com/photos/1082528/pexels-photo-1082528.jpeg?auto=compress&cs=tinysrgb&dpr=2&h=650&w=940" alt="work" />
                                </div>
                                <div className="work-overlay">
                                <div className="work-content">
                                    <h3 className="work-title">Product Design</h3>
                                    <ul>
                                    <li><a className="image-popup" href="assets/images/work/w-6.jpg"><i className="lni-cart" /></a></li>
                                    <li><Link to="/product-details"><i className="lni-eye" /></Link></li>
                                    </ul>
                                </div>
                                </div>
                                <div className="work-overlay-price">
                                    <p> $60.00 </p>
                                </div>  
                            </div> {/* single work */}
                        </div>
                        <div className="col-lg-4 col-md-6 col-sm-6">
                            <div className="single-work text-center mt-30">
                                <div className="work-image">
                                <img src="https://images.pexels.com/photos/45982/pexels-photo-45982.jpeg?auto=compress&cs=tinysrgb&dpr=2&h=650&w=940" alt="work" />
                                </div>
                                <div className="work-overlay">
                                <div className="work-content">
                                    <h3 className="work-title">Product Design</h3>
                                    <ul>
                                    <li><a className="image-popup" href="assets/images/work/w-6.jpg"><i className="lni-cart" /></a></li>
                                    <li><Link to="/product-details"><i className="lni-eye" /></Link></li>
                                    </ul>
                                </div>
                                </div>
                                <div className="work-overlay-price">
                                    <p> $60.00 </p>
                                </div>  
                            </div> {/* single work */}
                        </div>
                        <div className="col-lg-4 col-md-6 col-sm-6">
                            <div className="single-work text-center mt-30">
                                <div className="work-image">
                                <img src="https://images.pexels.com/photos/1082528/pexels-photo-1082528.jpeg?auto=compress&cs=tinysrgb&dpr=2&h=650&w=940" alt="work" />
                                </div>
                                <div className="work-overlay">
                                <div className="work-content">
                                    <h3 className="work-title">Product Design</h3>
                                    <ul>
                                    <li><a className="image-popup" href="assets/images/work/w-6.jpg"><i className="lni-cart" /></a></li>
                                    <li><Link to="/product-details"><i className="lni-eye" /></Link></li>
                                    </ul>
                                </div>
                                </div>
                                <div className="work-overlay-price">
                                    <p> $60.00 </p>
                                </div>  
                            </div> {/* single work */}
                        </div>
                        <div className="col-lg-4 col-md-6 col-sm-6">
                            <div className="single-work text-center mt-30">
                                <div className="work-image">
                                <img src="https://images.pexels.com/photos/45982/pexels-photo-45982.jpeg?auto=compress&cs=tinysrgb&dpr=2&h=650&w=940" alt="work" />
                                </div>
                                <div className="work-overlay">
                                <div className="work-content">
                                    <h3 className="work-title">Product Design</h3>
                                    <ul>
                                    <li><a className="image-popup" href="assets/images/work/w-6.jpg"><i className="lni-cart" /></a></li>
                                    <li><Link to="/product-details"><i className="lni-eye" /></Link></li>
                                    </ul>
                                </div>
                                </div>
                                <div className="work-overlay-price">
                                    <p> $60.00 </p>
                                </div>  
                            </div> {/* single work */}
                        </div>
                        
                        <Col lg={12} md={12}>
                            <div className="pagi-md">
                            <Pagination>
                                <Pagination.First />
                                <Pagination.Prev />
                                <Pagination.Item>{1}</Pagination.Item>
                                <Pagination.Ellipsis />

                                <Pagination.Item>{10}</Pagination.Item>
                                <Pagination.Item>{11}</Pagination.Item>
                                <Pagination.Item active>{12}</Pagination.Item>
                                <Pagination.Item>{13}</Pagination.Item>
                                <Pagination.Item disabled>{14}</Pagination.Item>

                                <Pagination.Ellipsis />
                                <Pagination.Item>{20}</Pagination.Item>
                                <Pagination.Next />
                                <Pagination.Last />
                            </Pagination>
                            </div>
                        </Col>
                    </Row>
                
              
                </Container>
            </section>

            {/*====== Video PART ENDS ======*/}

            {/*====== FOOTER PART START ======*/}
                <Footer/>
            {/*====== FOOTER PART END ======*/}
         
        </>
    );
}




export default Shop