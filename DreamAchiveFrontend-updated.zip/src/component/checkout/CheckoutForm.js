import React,{useState} from "react";
import { Col, Container, Pagination, Row, Form, Card, CardBody } from "react-bootstrap";
import Header from "../navbar/Header";
import { Link } from "react-router-dom";
import Footer from "../footer/Footer";
import { Tab, Tabs, TabList, TabPanel, } from 'react-tabs';
import 'react-tabs/style/react-tabs.css';
import ModalVideo from 'react-modal-video'
import ContentLoader, { Facebook } from 'react-content-loader'
import { BsStarHalf,BsStarFill,BsStar } from 'react-icons/bs';

import $ from "jquery";
import ImageGallery from 'react-image-gallery';
import "react-image-gallery/styles/css/image-gallery.css";
import Button from "@restart/ui/esm/Button";
 
function CheckoutForm(){
    const [isOpen, setOpen] = useState(false)
    const [count, setCount] = useState(0);

  
    return(

        <>
      
            {/*====== HEADER PART START ======*/}
                <Header/>
            {/*====== HEADER PART ENDS ======*/}

            {/*====== banner PART start ======*/}
            <section className="hero-banner-section">
                <Container>
                    <Row>
                        <Col md="12" xs="12">
                            <div className="hero-content">
                                <div className="cd-main"> 
                                    <h5> Checkout </h5> 
                                    <ul> 
                                        <li> <Link to="/" className=""> Home </Link> </li>
                                        <li> <Link to="/shop-view" className="active"> Checkout </Link>  </li>
                                      </ul>
                                </div>
                                
                            </div>
                        </Col>
                    </Row>
                </Container>
            </section>
            {/*====== Banner PART End ======*/}

            {/*====== BLOG PART START ======*/}
            <section className="blogs-section blogs-main"> 
                <Container>

                    <Row>

                        <div className="col-lg-8 col-md-8 col-sm-8 m-auto">
                            <div className="card">
                                <div className="card-body">
                                    <div className="biling-details-title">
                                        <h5> Billing Details  </h5>
                                    </div>

                                    <Row>
                                        <Col lg={6} md={6} xs={12}>
                                            <Form.Group className="mb-3" controlId="exampleForm.ControlInput1">
                                                <Form.Label>First Name</Form.Label>
                                                <Form.Control className="biling-form-field" type="email" placeholder="name@example.com" />
                                            </Form.Group>
                                        </Col>

                                        <Col lg={6} md={6} xs={12}>
                                            <Form.Group className="mb-3" controlId="exampleForm.ControlInput1">
                                                <Form.Label>Last Name</Form.Label>
                                                <Form.Control className="biling-form-field" type="email" placeholder="name@example.com" />
                                            </Form.Group>
                                        </Col>

                                        <Col lg={12} md={12} xs={12}>
                                            <Form.Group className="mb-3" controlId="exampleForm.ControlInput1">
                                                <Form.Label>Address</Form.Label>
                                                <Form.Control className="biling-form-field" type="email" placeholder="name@example.com" />
                                            </Form.Group>
                                        </Col>

                                        <Col lg={6} md={6} xs={12}>
                                            <Form.Group className="mb-3" controlId="exampleForm.ControlInput1">
                                                <Form.Label>City</Form.Label>
                                                <Form.Select className="biling-form-field" aria-label="Default select example">
                                                    <option>select</option>
                                                    <option value="1">One</option>
                                                    <option value="2">Two</option>
                                                    <option value="3">Three</option>
                                                </Form.Select>
                                            </Form.Group>
                                        </Col>

                                        <Col lg={6} md={6} xs={12}>
                                            <Form.Group className="mb-3" controlId="exampleForm.ControlInput1">
                                                <Form.Label>Postal code</Form.Label>
                                                <Form.Control className="biling-form-field" type="email" placeholder="name@example.com" />
                                            </Form.Group>
                                        </Col>

                                        <Col lg={6} md={6} xs={12}>
                                            <Form.Group className="mb-3" controlId="exampleForm.ControlInput1">
                                                <Form.Label>Country</Form.Label>
                                                <Form.Select className="biling-form-field" aria-label="Default select example">
                                                    <option>select</option>
                                                    <option value="1">One</option>
                                                    <option value="2">Two</option>
                                                    <option value="3">Three</option>
                                                </Form.Select>
                                            </Form.Group>
                                        </Col>

                                        <Col lg={6} md={6} xs={12}>
                                            <Form.Group className="mb-3" controlId="exampleForm.ControlInput1">
                                                <Form.Label>Region State</Form.Label>
                                                <Form.Select className="biling-form-field" aria-label="Default select example">
                                                    <option>select</option>
                                                    <option value="1">One</option>
                                                    <option value="2">Two</option>
                                                    <option value="3">Three</option>
                                                </Form.Select>
                                            </Form.Group>
                                        </Col>


                                       <Col lg={12} xs={12}>
                                           <div className="order-p-btn-d">
                                                <Button className="main-btn"> Place Order </Button>
                                           </div>
                                       </Col>


                                    </Row>
                                
                                </div>
                            </div>
                        </div>


                        <Col lg="4">
                           <div className="card summary-card">
                               <div className="card-body">
                                    <div className="order-summry biling-details-title">
                                        <h5> Summary </h5>
                                    </div>


                                    <div className="sumary-product">
                                        <ul>
                                            <li>
                                                <div className="summary-p-img">
                                                    <img src="assets/images/events.jpg" />
                                                </div>
                                                <div className="summary-p-title">
                                                <h6> Product title </h6>
                                                    <div className="qty-price">
                                                        <div className="qty">
                                                            <p>Qty : <span> 1 </span> </p>
                                                            
                                                        </div>

                                                        <div className="p-price">
                                                            <p> $50 </p>
                                                        </div>

                                                    </div>
                                                </div>
                                            </li>

                                            <li>
                                                <div className="summary-p-img">
                                                    <img src="assets/images/events.jpg" />
                                                </div>
                                                <div className="summary-p-title">
                                                <h6> Product title </h6>
                                                    <div className="qty-price">
                                                        <div className="qty">
                                                            <p>Qty : <span> 1 </span> </p>
                                                            
                                                        </div>

                                                        <div className="p-price">
                                                            <p> $50 </p>
                                                        </div>

                                                    </div>
                                                </div>
                                            </li>
                                      
                                        </ul>
                                    </div>
                               </div>
                           </div>
                        </Col>

                    </Row>
                
              
                </Container>
            </section>


            {/*====== FOOTER PART START ======*/}
                <Footer/>
            {/*====== FOOTER PART END ======*/}
         
        </>
    );
}




export default CheckoutForm