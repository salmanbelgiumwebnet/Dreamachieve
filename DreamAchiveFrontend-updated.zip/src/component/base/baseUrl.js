
const environment = {

// for localhost Environment
    BASE_URL : 'http://localhost:8080/dreamachieve/'


// for Production Environment


}

export default environment