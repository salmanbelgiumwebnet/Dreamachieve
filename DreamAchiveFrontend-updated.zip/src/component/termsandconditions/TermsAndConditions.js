import React, { useState, useEffect } from "react";
import { Col, Container, Row,Accordion,AccordionItem,AccordionBody} from "react-bootstrap";
import Header from "../navbar/Header";
import { Link } from "react-router-dom";
import Footer from "../footer/Footer";
import ModalVideo from 'react-modal-video'
import 'bootstrap/dist/css/bootstrap.min.css';


import environment from '../base/baseUrl'
import axios from 'axios';
import Swal from "sweetalert2";

function TermsAndConditions() {
    

    var BASE_URL = environment.BASE_URL;

    const [termsandcondition, setTermsAndCondition] = useState([])

    useEffect(() => {
        axios
            .get(BASE_URL + '/termsandcondition')
            .then(res => {
                setTermsAndCondition(res.data)
                console.clear();
                console.log(res.data)
            }).catch(err => {
                console.log(err)
            })
    }, [])

    return(

        <>
         
            {/*====== HEADER PART START ======*/}
            <Header/>
            {/*====== HEADER PART ENDS ======*/}

            {/*====== banner PART start ======*/}
            <section className="hero-banner-section">
                <Container>
                    <Row>
                        <Col md="12" xs="12">
                            <div className="hero-content">
                                <div className="cd-main"> 
                                    <h5> Terms And Conditions </h5> 
                                    <ul> 
                                        <li>   <Link to="/" className=""> Home </Link> </li>
                                        <li> <Link to="/termsandcondition" className="active"> privacy policy </Link>  </li>
                                      </ul>
                                </div>
                                
                            </div>
                        </Col>
                    </Row>
                </Container>
            </section>
            {/*====== Banner PART End ======*/}

            {/*====== About Section One START ======*/}
            <section className="blogs-section blogs-main"> 
                <Container>

                <div className="row justify-content-center">
                    <div className="col-lg-8">
                    <div className="section-title text-center pb-25">
                        <h2 className="title">Terms And Conditions</h2>
                    </div> 
                    </div>
                </div> {/* row */}

                    <Row>
                        <Col lg="12" md="12" xs="12">
                           <div className="privacy-text">
                               <h4> Lorem ipsum dollar site ameat dummy text. </h4>
                               <ul>
                                   <li> <p> Lorem ipsum dolor sit amet, consectetur adipiscing elit. Praesent pharetra ligula ac consectetur ullamcorper Lorem ipsum dolor sit amet, consectetur adipiscing elit. Praesent pharetra ligula ac consectetur ullamcorper. </p> </li>
                                   <li> <p> Lorem ipsum dolor sit amet, consectetur adipiscing elit. Praesent pharetra ligula ac consectetur ullamcorper Lorem ipsum dolor sit amet, consectetur adipiscing elit. Praesent pharetra ligula ac consectetur ullamcorper. </p> </li>
                                   <li> <p> Lorem ipsum dolor sit amet, consectetur adipiscing elit. Praesent pharetra ligula ac consectetur ullamcorper Lorem ipsum dolor sit amet, consectetur adipiscing elit. Praesent pharetra ligula ac consectetur ullamcorper. </p> </li>
                                   <li> <p> Lorem ipsum dolor sit amet, consectetur adipiscing elit. Praesent pharetra ligula ac consectetur ullamcorper Lorem ipsum dolor sit amet, consectetur adipiscing elit. Praesent pharetra ligula ac consectetur ullamcorper. </p> </li>
                                   

                               </ul>
                            </div>                 
                        </Col>

                        <Col lg="12" md="12" xs="12">
                           <div className="privacy-text">
                               <h4> Lorem ipsum dollar site ameat dummy text. </h4>
                               <ul>
                                   <li> <p> Lorem ipsum dolor sit amet, consectetur adipiscing elit. Praesent pharetra ligula ac consectetur ullamcorper Lorem ipsum dolor sit amet, consectetur adipiscing elit. Praesent pharetra ligula ac consectetur ullamcorper. </p> </li>
                                   <li> <p> Lorem ipsum dolor sit amet, consectetur adipiscing elit. Praesent pharetra ligula ac consectetur ullamcorper Lorem ipsum dolor sit amet, consectetur adipiscing elit. Praesent pharetra ligula ac consectetur ullamcorper. </p> </li>
                                   <li> <p> Lorem ipsum dolor sit amet, consectetur adipiscing elit. Praesent pharetra ligula ac consectetur ullamcorper Lorem ipsum dolor sit amet, consectetur adipiscing elit. Praesent pharetra ligula ac consectetur ullamcorper. </p> </li>
                                   <li> <p> Lorem ipsum dolor sit amet, consectetur adipiscing elit. Praesent pharetra ligula ac consectetur ullamcorper Lorem ipsum dolor sit amet, consectetur adipiscing elit. Praesent pharetra ligula ac consectetur ullamcorper. </p> </li>
                                   

                               </ul>
                            </div>                 
                        </Col>
                    </Row>

              
                </Container>
            </section>
            {/*====== about Section One ENDS ======*/}

          
            
            {/*====== FOOTER PART START ======*/}
                <Footer/>
            {/*====== FOOTER PART END ======*/}


        </>
        );
    
}



export default TermsAndConditions