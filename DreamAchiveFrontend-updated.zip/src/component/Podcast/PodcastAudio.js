import React, { useState, useEffect } from "react";
import { Col, Container, Row } from "react-bootstrap";
import Header from "../navbar/Header";
import { Link } from "react-router-dom";
import Footer from "../footer/Footer";
import AudioPlayer from 'react-h5-audio-player';
import 'react-h5-audio-player/lib/styles.css';

function PodcastAudio() {

    return (

        <>

            {/*====== HEADER PART START ======*/}
            <Header />
            {/*====== HEADER PART ENDS ======*/}

            {/*====== banner PART start ======*/}
            <section className="hero-banner-section">
                <Container>
                    <Row>
                        <Col md="12" xs="12">
                            <div className="hero-content">
                                <div className="cd-main">
                                    <h5> Podcast Audio </h5>
                                    <ul>
                                        <li>   <Link to="/" className=""> Home </Link> </li>
                                        <li> <Link to="/podcast" className="active"> podcast audio </Link>  </li>
                                    </ul>
                                </div>

                            </div>
                        </Col>
                    </Row>
                </Container>
            </section>
            {/*====== Banner PART End ======*/}

            {/*====== podcast PART START ======*/}


            <section className="blog-area pt-80 pb-130">
                <div className="container">
                    <Row >
                   
                        <Col md="12" xs="12" className="pd-0">
                           <div className="blogs-title cate-m-title mb-4">
                                <h3 className="title2"> Podcast  <strong> Episodes  </strong></h3>
                            </div>
                        </Col>
                  
            
                    </Row> {/* row */}
                    <Row>
                     
                        <Col lg="12" xs="12" className="ad-main">
                            <Row>
                            <Col lg="3" md="3" xs="12">
                            <div className="pd-cast-audio-img">
                                <img src="assets/images/events.jpg"/>
                            </div>
                        </Col>
                        <Col lg="9" xs="12">
                            <div className="podcast-audio-text">
                                <div className="audio-date">
                                 <span className="posted-on">
                                    13 September 2017
                                </span> 
                                    
                                </div>

                               <div className="m-title">
                                    <i class="fas fa-music"></i>
                                    <h5>
                                        A short wave goodbye for my good friend Francisco
                                    </h5>
                               </div>

                               <div className="audio-player-d">
                                    <AudioPlayer src="assets/file_example_MP3_1MG.mp3" layout="horizontal-reverse" />
                                </div>
                            </div>
                        </Col>
                        <Col lg="12" xs="12">
                        <p className="mt-a125"> 
                               Capicola jerky ham hock, pork doner jowl tail boudin strip steak rump kevin bresaola salami biltong 
                               cupim kevin tri-tip sirloin spare ribs turkey corned beef turkey cow short ribs  cupim kevin turkey corned beef turkey cow short ribs 
                               Capicola jerky ham hock, pork doner jowl tail boudin strip steak rump kevin bresaola salami biltong cupim kevin tri-tip sirloin spare ribs turkey corned beef turkey cow short ribs  cupim kevin turkey corned beef turkey cow short ribs… 
                               </p>
                        </Col>

                            </Row>
                        </Col>

                        
                     
                  
                    </Row> {/* row */}

                </div> {/* container */}
            </section>
            {/*====== Podcast PART ENDS ======*/}

            {/*====== FOOTER PART START ======*/}
            <Footer />
            {/*====== FOOTER PART END ======*/}


        </>
    );
}




export default PodcastAudio