import React, { useState, useEffect } from "react";
import { Col, Container, Row } from "react-bootstrap";
import Header from "../navbar/Header";
import { Link } from "react-router-dom";
import Footer from "../footer/Footer";
import { Tab, Tabs, TabList, TabPanel } from 'react-tabs';
import 'react-tabs/style/react-tabs.css';
import ModalVideo from 'react-modal-video'
import ContentLoader, { Facebook } from 'react-content-loader'


import environment from '../base/baseUrl'
import axios from 'axios';
import Swal from "sweetalert2";

function Podcast() {

    var BASE_URL = environment.BASE_URL;

    const [isOpen, setOpen] = useState(false)
    const [podcastPage, setPodcastPage] = useState([])
    const [podcastCategory, setPodcastCategory] = useState([])
    const [podcast, setPodcast] = useState([])

    useEffect(() => {
        axios
            .get(BASE_URL + '/podcastpage')
            .then(res => {
                setPodcastPage(res.data)
                console.clear();
                console.log(res.data)
            }).catch(err => {
                console.log(err)
            })
        axios
            .get(BASE_URL + '/podcastcategory')
            .then(res => {
                setPodcastCategory(res.data)
                console.log(res.data)
            }).catch(err => {
                console.log(err)
            })
        axios
            .get(BASE_URL + '/podcast')
            .then(res => {
                setPodcast(res.data)
                console.log(res.data)
            }).catch(err => {
                console.log(err)
            })
    }, [])
    return (

        <>

            {/*====== HEADER PART START ======*/}
            <Header />
            {/*====== HEADER PART ENDS ======*/}

            {/*====== banner PART start ======*/}
            <section className="hero-banner-section">
                <Container>
                    <Row>
                        <Col md="12" xs="12">
                            <div className="hero-content">
                                <div className="cd-main">
                                    <h5> Podcast </h5>
                                    <ul>
                                        <li>   <Link to="/" className=""> Home </Link> </li>
                                        <li> <Link to="/podcast" className="active"> podcast </Link>  </li>
                                    </ul>
                                </div>

                            </div>
                        </Col>
                    </Row>
                </Container>
            </section>
            {/*====== Banner PART End ======*/}

            {/*====== podcast PART START ======*/}


            <section className="blog-area pt-80 pb-130">
                <div className="container">
                    <div className="row justify-content-center">
                        <div className="col-lg-8">
                            <div className="section-title text-center pb-25">
                                <h3 className="title2"> LISTEN TO THE LATEST <span> PODCASTS </span> </h3>
                                <p>Nunc id dui at sapien faucibus fermentum ut vel diam. Nullam tempus, nunc id efficitur sagittis, urna est ultricies eros, ac porta sem turpis quis leo.</p>
                            </div> {/* section title */}
                        </div>
                    </div> {/* row */}
                    <div className="row justify-content-center">
                        <div className="col-lg-4 col-md-8 col-sm-9">
                            <div className="single-blog mt-30">
                                <div className="blog-image">
                                    <img src="assets/images/blog/b-1.jpg" alt="Blog" />
                                </div>
                                <div className="blog-content">
                                <h4 className="blog-title"><Link to="/podcast-audio">Hired Releases 2023 Brand Health.</Link></h4>
                                    <span>July 26, 2022</span>
                                </div>
                            </div>
                        </div>
                        <div className="col-lg-4 col-md-8 col-sm-9">
                            <div className="single-blog mt-30">
                                <div className="blog-image">
                                    <img src="assets/images/blog/b-2.jpg" alt="Blog" />
                                </div>
                                <div className="blog-content">
                                <h4 className="blog-title"><Link to="/podcast-audio">Hired Releases 2023 Brand Health.</Link></h4>
                                    <span>July 26, 2022</span>
                                </div>
                            </div>
                        </div>
                        <div className="col-lg-4 col-md-8 col-sm-9">
                            <div className="single-blog mt-30">
                                <div className="blog-image">
                                    <img src="assets/images/blog/b-3.jpg" alt="Blog" />
                                </div>
                                <div className="blog-content">
                                    <h4 className="blog-title"><Link to="/podcast-audio">Hired Releases 2023 Brand Health.</Link></h4>
                                    <span>July 26, 2022</span>
                                </div>
                            </div>
                        </div>
                    </div> {/* row */}

                </div> {/* container */}
            </section>
            {/*====== Podcast PART ENDS ======*/}

            {/*====== FOOTER PART START ======*/}
            <Footer />
            {/*====== FOOTER PART END ======*/}


        </>
    );
}




export default Podcast