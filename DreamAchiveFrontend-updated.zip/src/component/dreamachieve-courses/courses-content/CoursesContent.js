import React,{useState} from "react";
import { Col, Container, Nav, Row } from "react-bootstrap";
import Header from "../../navbar/Header";
import { Link } from "react-router-dom";
import Footer from "../../footer/Footer";
import { Tab, Tabs, TabList, TabPanel } from 'react-tabs';
import 'react-tabs/style/react-tabs.css';
import ModalVideo from 'react-modal-video'
import ContentLoader, { Facebook } from 'react-content-loader'

function CoursesContent(props){
    const [isOpen, setOpen] = useState(false)

    const shoot = () => {
        alert("Great Shot!");
      }
    return(

        <>
      
            {/*====== HEADER PART START ======*/}
                <Header/>
            {/*====== HEADER PART ENDS ======*/}

            {/*====== banner PART start ======*/}
            <section className="hero-banner-section">
                <Container>
                    <Row>
                        <Col md="12" xs="12">
                            <div className="hero-content">
                                <div className="cd-main"> 
                                    <h5> Courses Content </h5> 
                                    <ul> 
                                        <li> <Link to="/" className=""> Home </Link> </li>
                                        <li> <Link to="/courses-category" className="active"> Courses Content </Link>  </li>
                                      </ul>
                                </div>
                                
                            </div>
                        </Col>
                    </Row>
                </Container>
            </section>
            {/*====== Banner PART End ======*/}

            {/*====== BLOG PART START ======*/}
            <section className="blogs-section blogs-main"> 
                <Container>
                    {/* <Row>
                        <Col md="12" xs="12">
                           <div className="blogs-title cate-m-title">
                                <h3 className="title2"> Courses <strong>  Content  </strong></h3>
                            </div>
                        </Col>
                    </Row> */}

                   
                   <Row>
                       <Col md="12" xs="12">
                       <div className="video-tabs-main-d courses">
                                <Tabs>
                                    <TabList className="tab-menu">
                                        <Tab onClick={shoot}>Dealing with Pressure</Tab>
                                        <Tab  onClick={shoot}>Focus</Tab>
                                        <Tab onClick={shoot}> Mental health</Tab>
                                        <Tab onClick={shoot}>Emotional Management</Tab>
                                       
                                    </TabList>

                                    <TabPanel>
                                        <Row>
                                            <Col md="4" xs="12">
                                                <div className="video-box">
                                                    <div className="video-btn-icn" onClick={() => setOpen(true)}>
                                                        <i class="fa fa-play" aria-hidden="true"></i>
                                                    </div>
                                                    <div className="video-text">
                                                        <h6> Lorem ipsum dollar </h6>
                                                        <p> By lorem ipsum </p>
                                                    </div>
                                                </div>
                                            </Col>

                                            <Col md="4" xs="12">
                                                <div className="video-box" >
                                                    <div className="video-btn-icn" onClick={() => setOpen(true)}>
                                                        <i class="fa fa-play" aria-hidden="true"></i>
                                                    </div>
                                                    <div className="video-text">
                                                        <h6> Lorem ipsum dollar </h6>
                                                        <p> By lorem ipsum </p>
                                                    </div>
                                                </div>
                                            </Col>

                                            <Col md="4" xs="12">
                                                <div className="video-box">
                                                    <div className="video-btn-icn" onClick={() => setOpen(true)}>
                                                        <i class="fa fa-play" aria-hidden="true"></i>
                                                    </div>
                                                    <div className="video-text">
                                                        <h6> Lorem ipsum dollar </h6>
                                                        <p> By lorem ipsum </p>
                                                    </div>
                                                </div>
                                            </Col>

                                        </Row>
                                    </TabPanel>
                                    <TabPanel>
                                        <Row>
                                            <Col md="4" xs="12">
                                                <div className="video-box">
                                                    <div className="video-btn-icn" onClick={() => setOpen(true)}>
                                                        <i class="fa fa-play" aria-hidden="true"></i>
                                                    </div>
                                                    <div className="video-text">
                                                        <h6> Lorem ipsum dollar </h6>
                                                        <p> By lorem ipsum </p>
                                                    </div>
                                                </div>
                                            </Col>
                                        </Row>

                                    </TabPanel>
                                    <TabPanel>
                                        <Row>
                                            <Col md="4" xs="12">
                                                <div className="video-box" >
                                                    <div className="video-btn-icn" onClick={() => setOpen(true)}>
                                                        <i class="fa fa-play" aria-hidden="true"></i>
                                                    </div>
                                                    <div className="video-text">
                                                        <h6> Lorem ipsum dollar </h6>
                                                        <p> By lorem ipsum </p>
                                                    </div>
                                                </div>
                                            </Col>
                                        </Row>
                                    </TabPanel>
                                    <TabPanel>
                                        <Row>
                                            <Col md="4" xs="12">
                                                <div className="video-box">
                                                    <div className="video-btn-icn" onClick={() => setOpen(true)}>
                                                        <i class="fa fa-play" aria-hidden="true"></i>
                                                    </div>
                                                    <div className="video-text">
                                                        <h6> Lorem ipsum dollar </h6>
                                                        <p> By lorem ipsum </p>
                                                    </div>
                                                </div>
                                            </Col>
                                        </Row>
                                    </TabPanel>
                                  

                                </Tabs>


                            </div>



                           <div className="course-content-tab-main d-none">
                            <div className="tbs-ul-main">

                            <Nav variant="pills" defaultActiveKey="/courses-content">
                                <Nav.Item>
                                    <Nav.Link href="/courses-content">Dealing with Pressure</Nav.Link>
                                </Nav.Item>
                                <Nav.Item>
                                    <Nav.Link eventKey="link-1">Focus</Nav.Link>
                                </Nav.Item>
                                <Nav.Item>
                                    <Nav.Link eventKey="link-2" >
                                        Mental health
                                    </Nav.Link>
                                </Nav.Item>

                                <Nav.Item>
                                    <Nav.Link eventKey="link-3" >
                                    Emotional Management
                                    </Nav.Link>
                                </Nav.Item>

                            </Nav>
                                {/* <ul>
                                    <li>
                                        <p>
                                            Category 1
                                        </p>
                                    </li>
                                    <li>
                                        <p>
                                            Category 1
                                        </p>
                                    </li>
                                    <li>
                                        <p>
                                            Category 1
                                        </p>
                                    </li>
                                    <li>
                                        <p>
                                            Category 1
                                        </p>
                                    </li>
                                </ul> */}
                            </div> 
                            <Row>
                            <Col md="4" xs="12">
                                <div className="video-box ">
                                    <div className="video-btn-icn" onClick={()=> setOpen(true)}>
                                    <i class="fa fa-play" aria-hidden="true"></i>
                                    </div>
                                    <div className="video-text">
                                        <h6> Lorem ipsum dollar </h6>
                                        <p> By lorem ipsum </p>
                                    </div>
                                </div>
                            </Col>
                            </Row>
                           </div>
                       </Col>
                   </Row>
                

                </Container>
            </section>

            {/*====== BLOG PART ENDS ======*/}

            {/*====== FOOTER PART START ======*/}
                <Footer/>
            {/*====== FOOTER PART END ======*/}

            <ModalVideo channel='youtube' autoplay isOpen={isOpen} videoId="77ZozI0rw7w" onClose={() => setOpen(false)} />

           
        </>
    );
}




export default CoursesContent