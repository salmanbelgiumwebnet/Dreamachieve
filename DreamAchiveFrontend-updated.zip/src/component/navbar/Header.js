import React, { useState, useEffect } from "react";
import { Link, NavLink, } from "react-router-dom";
import { Button, Dropdown, DropdownButton, Modal } from 'react-bootstrap';

import environment from '../base/baseUrl'
import axios from 'axios';
import { RiShoppingCartFill } from 'react-icons/ri';

function Header() {

  var BASE_URL = environment.BASE_URL;

  const [logo, setLogo] = useState([])
  const [menu, setMenu] = useState([])
  const [lgShow, setLgShow] = useState(false);


  const productData = [
    {
        "id": 1,
        "image": "https://images.pexels.com/photos/8532638/pexels-photo-8532638.jpeg?auto=compress&cs=tinysrgb&dpr=2&h=650&w=940",
        "name": "Coke - Diet, 355 Ml",
        "price": 120,
        "qty": 1,
    },
    {
        "id": 2,
        "image": "http://dummyimage.com/440x620.png/dddddd/000000",
        "name": "Pork - Hock And Feet Attached",
        "price": 150,
        "qty": 1,
    },
    {
        "id": 3,
        "image": "https://images.pexels.com/photos/8532638/pexels-photo-8532638.jpeg?auto=compress&cs=tinysrgb&dpr=2&h=650&w=940",
        "name": "Veal - Jambu",
        "price": 135,
        "qty": 1,
    },
    {
        "id": 4,
        "image": "http://dummyimage.com/440x620.png/dddddd/000000",
        "name": "Almonds Ground Blanched",
        "price": 110,
        "qty": 1,
    },
    {
        "id": 5,
        "image": "https://images.pexels.com/photos/8532638/pexels-photo-8532638.jpeg?auto=compress&cs=tinysrgb&dpr=2&h=650&w=940",
        "name": "Passion Fruit",
        "price": 80,
        "qty": 1,
    }
]
const [products, SetProducts] = useState(productData);

// -----Increment Event------
const increaseQuantity = (i) => {
    SetProducts((preValue) =>
        preValue.map((data, o) => {
            if (i === o) {
                return {
                    ...data,
                    qty: data.qty + 1
                };
            }
            return data;
        })
    );
};

// -----Decrement Event------
const decreaseQuantity = (i) => {
    SetProducts((preValue) =>
        preValue.map((data, o) => {
            if (i === o) {
                if (data.qty > 1) {
                    return { ...data, qty: data.qty - 1 };
                } else {
                    return data;
                }
            }
            return data;
        })
    );
};



// -----Remove Event------
const removeFromCart = (i) => {
    if (window.confirm("Are you sure you want to remove into your cart?")) {
        SetProducts(prevCart =>
            prevCart.filter((item, o) => {
                return i !== o;
            })
        );
       
    } else {
        // alert('No');
    }
};


// -empty-cart--------
const emptycart = () => {
    if (window.confirm("Remove all items into your cart?")) {
        SetProducts([]);
    } else {
        // alert('No');
    }
}

// ------Total Product Incart and Total Price of cart
const cartTotalQty = products.reduce((acc, data) => acc + data.qty, 0);
const cartTotalAmount = products.reduce((acc, data) => acc + data.price * data.qty, 0);







  useEffect(() => {
    axios
      .get(BASE_URL + '/logo')
      .then(res => {
        setLogo(res.data)
        console.clear();
        console.log(res.data)
      }).catch(err => {
        console.log(err)
      })
    axios
      .get(BASE_URL + '/menus')
      .then(res => {
        setMenu(res.data)
        console.log(res.data)
      }).catch(err => {
        console.log(err)
      })
  }, [])
  return (
    <>
      {/* <div className="preloader">
            <div className="loader_34">
                <div className="ytp-spinner">
                <div className="ytp-spinner-container">
                    <div className="ytp-spinner-rotator">
                    <div className="ytp-spinner-left">
                        <div className="ytp-spinner-circle" />
                    </div>
                    <div className="ytp-spinner-right">
                        <div className="ytp-spinner-circle" />
                    </div>
                    </div>
                </div>
                </div>
            </div>
            </div> */}
      {/*====== PRELOADER ENDS START ======*/}

      <header id="home" className="header-area">
        <div className="navigation fixed-top">
          <div className="container">
            <div className="row">
              <div className="col-lg-12">
                <nav className="navbar navbar-expand-lg">
                  <Link className="navbar-brand mn-logo" to="/">
                    <img src="assets/images/logo.png" alt="Logo" />
                  </Link> {/* Logo */}
                  <button className="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
                    <span className="toggler-icon" />
                    <span className="toggler-icon" />
                    <span className="toggler-icon" />
                  </button>
                  <div className="collapse navbar-collapse" id="navbarSupportedContent">
                    <ul className="navbar-nav ml-auto">
                      <li className="nav-item "><NavLink className="page-scroll" to="/">Home</NavLink></li>
                      <li className="nav-item"><NavLink className="page-scroll" to="/about">About</NavLink></li>
                      <li className="nav-item"><NavLink className="page-scroll" to="/programs">Programas</NavLink></li>
                      <li className="nav-item"><NavLink className="page-scroll" to="/shop">Store</NavLink></li>
                    
                      
                      <li className="nav-item drop-d-menu">
                        <DropdownButton id="dropdown-basic-button" title="DreamAchieve Courses ">
                          <Dropdown.Item> <Link to="/courses-category"> Sport </Link> </Dropdown.Item>
                          <Dropdown.Item> <Link to="/companies"> Companies </Link> </Dropdown.Item>
                          <Dropdown.Item> <Link to="/sport-psychologists"> Sport Psychologists </Link></Dropdown.Item>
                    
                        </DropdownButton>
                      </li>
                      <li className="nav-item drop-d-menu">
                        <DropdownButton id="dropdown-basic-button" title="Resources ">
                          <Dropdown.Item> <Link to="/video"> Videos </Link> </Dropdown.Item>
                          <Dropdown.Item> <Link to="/podcast"> Podcast </Link> </Dropdown.Item>
                          <Dropdown.Item> <Link to="/blogs"> Blogs </Link></Dropdown.Item>
                          <Dropdown.Item> <Link to="/faq"> Faq </Link></Dropdown.Item>
                          <Dropdown.Item> <Link to="/privacy"> Privacy Policy </Link></Dropdown.Item>
                          <Dropdown.Item> <Link to="/termsandcondition"> Terms And Conditions </Link></Dropdown.Item>
                        </DropdownButton>
                      </li>
                      <li className="nav-item"><NavLink className="page-scroll" to="/contact">Contactos</NavLink></li>
                      <li className="nav-item">  <NavLink to="/cart" className="cart-btn">  <RiShoppingCartFill />  </NavLink> </li>
                    
                      
                      {/* <li className="nav-item">  <button className="cart-btn" onClick={() => setLgShow(true)}>  <RiShoppingCartFill />  </button> </li> */}
                    
                    </ul>
                  </div> {/* navbar collapse */}
                </nav> {/* navbar */}
              </div>
            </div> {/* row */}
          </div> {/* container */}
        </div> {/* navigation */}

      </header>

    
    {/* Cart modal  */} 
      <Modal
        size="lg"
        centered
        show={lgShow}
        onHide={() => setLgShow(false)}
        aria-labelledby="example-modal-sizes-title-lg"
      >
        <Modal.Header closeButton className="cart-modal-header">
            
        </Modal.Header>
        <Modal.Body className="pd-0">
        <div className="row justify-content-center m-0">
                    <div className="col-md-12 pd-0">
                    <div className="card cart-card pd-0">
                            <div className="card-header bg-dark p-3 bd-r-0">
                                <div className="card-header-flex">
                                    <h6 className="text-white m-0">Cart Item {products.length > 0 ? `(${products.length})` : ''}</h6>
                                    {
                                        products.length > 0 ? <button className="btn btn-danger mt-0 btn-sm" onClick={() => emptycart()}><i className="fa fa-trash-alt mr-2"></i><span>Remove All</span></button> : ''}
                                </div>
                            </div>
                            <div className="card-body p-0">
                                {
                                    products.length === 0 ? <table className="table cart-table mb-0">
                                        <tbody>
                                            <tr>
                                                <td colSpan="6">
                                                    <div className="cart-empty">
                                                        <i className="fa fa-shopping-cart"></i>
                                                        <p>Your Cart Is empty</p>
                                                    </div>
                                                </td>
                                            </tr>
                                        </tbody>
                                    </table> :
                                        <table className="table cart-table mb-0">
                                            <thead>
                                                <tr>
                                                    <th>Action</th>
                                                    <th>Product</th>
                                                    <th>Name</th>
                                                    <th>Price</th>
                                                    <th>Qty</th>
                                                    <th className="text-right"><span id="amount" className="amount">Price</span></th>
                                                </tr>
                                            </thead>
                                            <tbody>
                                                {
                                                    products.map((data, index) => {
                                                        const { id, image, name, price, qty } = data;
                                                        return (
                                                            <tr key={index}>
                                                                <td><button className="prdct-delete" onClick={() => removeFromCart(index)}><i className="fa fa-trash-alt"></i></button></td>
                                                                <td><div className="product-img"><img src={image} alt="" /></div></td>
                                                                <td><div className="product-name"><p>{name}</p></div></td>
                                                                <td>${price}</td>
                                                                <td>
                                                                    <div className="prdct-qty-container">
                                                                        <button className="" type="button" onClick={() => decreaseQuantity(index)}>
                                                                            <i className="fa fa-minus"></i>
                                                                        </button>
                                                                        <input type="text" name="qty" className="qty-input-box" value={qty} disabled />
                                                                        <button className="" type="button" onClick={() => increaseQuantity(index)}>
                                                                            <i className="fa fa-plus"></i>
                                                                        </button>
                                                                    </div>
                                                                </td>
                                                                <td className="text-right">${(qty * price).toFixed(0)}</td>
                                                            </tr>
                                                        )
                                                    })
                                                }
                                            </tbody>
                                            <tfoot>
                                                <tr>
                                                    <th>&nbsp;</th>
                                                    <th colSpan="3">&nbsp;</th>
                                                    <th>Items in Cart<span className="ml-2 mr-2">:</span><span className="text-danger">{cartTotalQty}</span></th>
                                                    <th className="text-right">Total Price<span className="ml-2 mr-2">:</span><span className="text-danger">$ {cartTotalAmount.toFixed(0)}</span></th>
                                                </tr>
                                            </tfoot>
                                        </table>
                                }
                            </div>
                        </div>
                    </div>

                    <button className="checkout-btn"> PROCEED TO CHECKOUT  </button>
                </div>
       
        </Modal.Body>
      </Modal>

    </>
  );
}


export default Header