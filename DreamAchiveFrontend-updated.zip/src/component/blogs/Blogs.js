import React, { useState, useEffect } from "react";
import { Col, Container, Row } from "react-bootstrap";
import Header from "../navbar/Header";
import { Link } from "react-router-dom";
import Footer from "../footer/Footer";
import { Tab, Tabs, TabList, TabPanel } from 'react-tabs';
import 'react-tabs/style/react-tabs.css';
import ModalVideo from 'react-modal-video'
import ContentLoader, { Facebook } from 'react-content-loader'

import environment from '../base/baseUrl'
import axios from 'axios';
import Swal from "sweetalert2";
function Blogs() {

    var BASE_URL = environment.BASE_URL;

    const [blogpage, setBlogpage] = useState([])
    const [blog, setBlog] = useState([])

    useEffect(() => {
        axios
            .get(BASE_URL + '/blogpage')
            .then(res => {
                setBlogpage(res.data)
                console.clear();
                console.log(res.data)
            }).catch(err => {
                console.log(err)
            })
        axios
            .get(BASE_URL + '/blogs')
            .then(res => {
                setBlog(res.data)
                console.log(res.data)
            }).catch(err => {
                console.log(err)
            })
    }, [])

    return (


        <>

            {/*====== HEADER PART START ======*/}
            <Header />
            {/*====== HEADER PART ENDS ======*/}

            {/*====== banner PART start ======*/}
            <section className="hero-banner-section">
                <Container>
                    <Row>
                        <Col md="12" xs="12">
                            <div className="hero-content">
                                <div className="cd-main">
                                    <h5> Blogs </h5>
                                    <ul>
                                        <li>   <Link to="/" className=""> Home </Link> </li>
                                        <li> <Link to="/blogs" className="active"> blogs </Link>  </li>
                                    </ul>
                                </div>

                            </div>
                        </Col>
                    </Row>
                </Container>
            </section>
            {/*====== Banner PART End ======*/}

            {/*====== BLOG PART START ======*/}
            <section className="blogs-section blogs-main">
                <Container>
                    <Row>
                        <Col md="12" xs="12">
                            <div className="blogs-title ">
                                <h3 className="title2"> Nádia Tavares <span> Blogs </span> </h3>
                                <p> Lorem Ipsum is simply dummy text of the printing and typesetting industry. </p>
                            </div>
                        </Col>
                    </Row>

                    <Row>
                        <Col md="4" xs="12">
                            <div className="blog-box">
                                <div className="blog-img">
                                    <img src="https://via.placeholder.com/400x280" />
                                </div>
                                <div className="blog-text-d">
                                    <Link to=""> <h5> Coach Cerftification Programas Most Powerful Coach </h5> </Link>
                                    <p>
                                        Lorem Ipsum is simply dummy text of the printing
                                        and typesetting industry  Lorem Ipsum is simply dummy text of the printing and
                                    </p>
                                    <button className="blog-btn"> View More </button>
                                </div>
                            </div>
                        </Col>

                        <Col md="4" xs="12">
                            <div className="blog-box">
                                <div className="blog-img">
                                    <img src="https://via.placeholder.com/400x280" />
                                </div>
                                <div className="blog-text-d">
                                    <Link to=""> <h5> Coach Cerftification Programas Most Powerful Coach </h5> </Link>
                                    <p>
                                        Lorem Ipsum is simply dummy text of the printing
                                        and typesetting industry  Lorem Ipsum is simply dummy text of the printing and
                                    </p>
                                    <button className="blog-btn"> View More </button>
                                </div>
                            </div>
                        </Col>
                        <Col md="4" xs="12">
                            <div className="blog-box">
                                <div className="blog-img">
                                    <img src="https://via.placeholder.com/400x280" />
                                </div>
                                <div className="blog-text-d">
                                    <Link to=""> <h5> Coach Cerftification Programas Most Powerful Coach </h5> </Link>
                                    <p>
                                        Lorem Ipsum is simply dummy text of the printing
                                        and typesetting industry  Lorem Ipsum is simply dummy text of the printing and
                                    </p>
                                    <button className="blog-btn"> View More </button>
                                </div>
                            </div>
                        </Col>
                    </Row>

                </Container>
            </section>



            {/*====== BLOG PART ENDS ======*/}

            {/*====== FOOTER PART START ======*/}
            <Footer />
            {/*====== FOOTER PART END ======*/}


        </>
    );
}




export default Blogs