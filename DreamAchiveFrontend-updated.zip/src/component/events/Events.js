import React,{useState} from "react";
import { Col, Container, Pagination, Row } from "react-bootstrap";
import Header from "../navbar/Header";
import { Link } from "react-router-dom";
import Footer from "../footer/Footer";
import 'react-tabs/style/react-tabs.css';
import { MdLocationOn } from 'react-icons/md';

function Events(){
    const [isOpen, setOpen] = useState(false)
    return(

        <>
      
            {/*====== HEADER PART START ======*/}
                <Header/>
            {/*====== HEADER PART ENDS ======*/}

            {/*====== banner PART start ======*/}
            <section className="hero-banner-section">
                <Container>
                    <Row>
                        <Col md="12" xs="12">
                            <div className="hero-content">
                                <div className="cd-main"> 
                                    <h5> Events </h5> 
                                    <ul> 
                                        <li>   <Link to="/" className=""> Home </Link> </li>
                                        <li> <Link to="/events" className="active"> events </Link>  </li>
                                      </ul>
                                </div>
                                
                            </div>
                        </Col>
                    </Row>
                </Container>
            </section>
            {/*====== Banner PART End ======*/}

            {/*====== BLOG PART START ======*/}
            <section className="blogs-section blogs-main"> 
                <Container>
                    <Row>
                        <Col md="12" xs="12">
                            <div className="section-title text-center">
                                <h2 className="title">Events </h2>
                            </div> {/* section title */}
                        </Col>
                    </Row>

                    <Row>
                        <Col lg="6 m-auto" md="12" xs="12">
                            <div className="event-box-main in-box" >
                                <div className="event-b-1 inner">
                                    <img src="https://images.pexels.com/photos/976866/pexels-photo-976866.jpeg?auto=compress&cs=tinysrgb&dpr=2&h=650&w=940" />
                                    <button className="main-btn btn-events overlay"> Upcomming  </button>
                                </div>
                                <div className="event-text-d events-in">
                                    <div className="d-1">
                                    <h5> Lorem ipsum dollar site ameat dummy text.</h5>
                                    <p className="event-date"> 01/02/2022 </p>
                                    <p className="event-text">    Curabitur vitae magna felis. Nulla ac libero ornare, vestibulum lacus quis blandit enimdicta sunt. Curabitur vitae magna felis.   Curabitur vitae magna felis. Nulla ac libero ornare, vestibulum lacus quis blandit enimdicta sunt. Curabitur vitae magna felis.
                                     </p>
                                    </div>
                                    <div className="d2">
                                    <p className="address-text"> <div className="add-icn"> <MdLocationOn/> </div> <span> 123 Stree New York City , United States Of America 750  United States Of America 750 </span></p>
                                   
                                    </div>
                                   
                                </div> 
                            </div>
                           
                        </Col>

                        <Col lg="6 m-auto" md="12" xs="12">
                            <div className="event-box-main in-box" >
                                <div className="event-b-1 inner">
                                <img src="https://images.pexels.com/photos/976866/pexels-photo-976866.jpeg?auto=compress&cs=tinysrgb&dpr=2&h=650&w=940" />
                                    <button className="main-btn btn-events overlay"> Upcomming  </button>
                                </div>
                                <div className="event-text-d events-in">
                                    <h5> Lorem ipsum dollar site ameat dummy text.</h5>
                                    <p className="event-date"> 01/02/2022 </p>
                                    <p className="event-text">    Curabitur vitae magna felis. Nulla ac libero ornare, vestibulum lacus quis blandit enimdicta sunt. Curabitur vitae magna felis.   Curabitur vitae magna felis. Nulla ac libero ornare, vestibulum lacus quis blandit enimdicta sunt. Curabitur vitae magna felis.
                                     </p>
                                     <p className="address-text"> <div className="add-icn"> <MdLocationOn/> </div> <span> 123 Stree New York City , United States Of America 750  United States Of America 750 </span></p>
                                   
                                   
                                </div> 
                            </div>
                           
                        </Col>
                        <Col lg="6 m-auto" md="12" xs="12">
                            <div className="event-box-main in-box" >
                                <div className="event-b-1 inner">
                                <img src="https://images.pexels.com/photos/976866/pexels-photo-976866.jpeg?auto=compress&cs=tinysrgb&dpr=2&h=650&w=940" />
                                     <button className="main-btn btn-events overlay"> Upcomming  </button>
                                </div>
                                <div className="event-text-d events-in">
                                    <h5> Lorem ipsum dollar site ameat dummy text.</h5>
                                    <p className="event-date"> 01/02/2022 </p>
                                    <p className="event-text">    Curabitur vitae magna felis. Nulla ac libero ornare, vestibulum lacus quis blandit enimdicta sunt. Curabitur vitae magna felis.   Curabitur vitae magna felis. Nulla ac libero ornare, vestibulum lacus quis blandit enimdicta sunt. Curabitur vitae magna felis.
                                     </p>
                                     <p className="address-text"> <div className="add-icn"> <MdLocationOn/> </div> <span> 123 Stree New York City , United States Of America 750  United States Of America 750 </span></p>
                                   
                                   
                                </div> 
                            </div>
                           
                        </Col>

                        <Col lg="6 m-auto" md="12" xs="12">
                            <div className="event-box-main in-box" >
                                <div className="event-b-1 inner">
                                <img src="https://images.pexels.com/photos/976866/pexels-photo-976866.jpeg?auto=compress&cs=tinysrgb&dpr=2&h=650&w=940" />
                                     <button className="main-btn btn-events overlay"> Upcomming  </button>
                                </div>
                                <div className="event-text-d events-in">
                                    <h5> Lorem ipsum dollar site ameat dummy text.</h5>
                                    <p className="event-date"> 01/02/2022 </p>
                                    <p className="event-text">    Curabitur vitae magna felis. Nulla ac libero ornare, vestibulum lacus quis blandit enimdicta sunt. Curabitur vitae magna felis.   Curabitur vitae magna felis. Nulla ac libero ornare, vestibulum lacus quis blandit enimdicta sunt. Curabitur vitae magna felis.
                                     </p>
                                     <p className="address-text"> <div className="add-icn"> <MdLocationOn/> </div> <span> 123 Stree New York City , United States Of America 750  United States Of America 750 </span></p>
                                   
                                   
                                </div> 
                            </div>
                           
                        </Col>

                    </Row>
                
              
                </Container>
            </section>

            {/*====== Video PART ENDS ======*/}

            {/*====== FOOTER PART START ======*/}
                <Footer/>
            {/*====== FOOTER PART END ======*/}
         
        </>
    );
}




export default Events