import React,{useState} from "react";
import { Col, Container, Pagination, Row } from "react-bootstrap";
import Header from "../navbar/Header";
import { Link } from "react-router-dom";
import Footer from "../footer/Footer";
import 'react-tabs/style/react-tabs.css';
import { BsStarHalf,BsStarFill,BsStar } from 'react-icons/bs';
import $ from "jquery";
import ImageGallery from 'react-image-gallery';
import "react-image-gallery/styles/css/image-gallery.css";

const images = [
    {
      original: 'https://images.pexels.com/photos/8532616/pexels-photo-8532616.jpeg?auto=compress&cs=tinysrgb&dpr=2&h=650&w=940',
      thumbnail: 'https://images.pexels.com/photos/8532616/pexels-photo-8532616.jpeg?auto=compress&cs=tinysrgb&dpr=2&h=650&w=940',
    },
    {
      original: 'https://images.pexels.com/photos/8532638/pexels-photo-8532638.jpeg?auto=compress&cs=tinysrgb&dpr=2&h=650&w=940',
      thumbnail: 'https://images.pexels.com/photos/8532638/pexels-photo-8532638.jpeg?auto=compress&cs=tinysrgb&dpr=2&h=650&w=940',
    },
    {
      original: 'https://images.pexels.com/photos/4066292/pexels-photo-4066292.jpeg?auto=compress&cs=tinysrgb&dpr=2&h=650&w=940',
      thumbnail: 'https://images.pexels.com/photos/4066292/pexels-photo-4066292.jpeg?auto=compress&cs=tinysrgb&dpr=2&h=650&w=940',
    },
    {
        original: 'https://images.pexels.com/photos/9558695/pexels-photo-9558695.jpeg?auto=compress&cs=tinysrgb&dpr=2&h=650&w=940',
        thumbnail: 'https://images.pexels.com/photos/9558695/pexels-photo-9558695.jpeg?auto=compress&cs=tinysrgb&dpr=2&h=650&w=940',
    },
    {
    original: 'https://images.pexels.com/photos/7319146/pexels-photo-7319146.jpeg?auto=compress&cs=tinysrgb&dpr=2&h=650&w=940',
    thumbnail: 'https://images.pexels.com/photos/7319146/pexels-photo-7319146.jpeg?auto=compress&cs=tinysrgb&dpr=2&h=650&w=940',
    },

  ];
  
function ProductDetails(){
    const [isOpen, setOpen] = useState(false)
    const [count, setCount] = useState(0);

 // handleIncrement event handler
 const handleIncrement = () => {
   setCount(prevCount => prevCount + 1);
 };

 // handleDecrement event handler
 const handleDecrement = () => {
    if(count <= 0) {
    return;
    } else {
        setCount(count - 1);
    }
 };
      
    return(

        <>
      
            {/*====== HEADER PART START ======*/}
                <Header/>
            {/*====== HEADER PART ENDS ======*/}

            {/*====== banner PART start ======*/}
            <section className="hero-banner-section">
                <Container>
                    <Row>
                        <Col md="12" xs="12">
                            <div className="hero-content">
                                <div className="cd-main"> 
                                    <h5> Product Details </h5> 
                                    <ul> 
                                        <li>   <Link to="/" className=""> Home </Link> </li>
                                        <li> <Link to="/shop-view" className="active"> product details </Link>  </li>
                                      </ul>
                                </div>
                                
                            </div>
                        </Col>
                    </Row>
                </Container>
            </section>
            {/*====== Banner PART End ======*/}

            {/*====== BLOG PART START ======*/}
            <section className="blogs-section blogs-main"> 
                <Container>

                    <Row>
                        <div className="col-lg-6 col-md-6 col-sm-6">

                            <div className="product-view-img">
                                <ImageGallery 
                                items={images}
                                showFullscreenButton={false}
                                showPlayButton={false} />

                            </div>
                    
                        </div>
                        
                        <div className="col-lg-6 col-md-6 col-sm-6">
                           <div className="product-view-mn">
                                    <div className="product-view-title">
                                        <h4> Black Crew Tshirt  </h4>
                                        <div className="prod-raint-star">
                                          <BsStarFill />
                                          <BsStarFill />
                                          <BsStarFill />
                                          <BsStarHalf />
                                          <BsStar />

                                          <div className="prod-review">
                                                <p className="review-badge"> 4.5 </p>
                                                <p> 99 Review </p>
                                          </div>

                                        </div>
                                       
                                    </div>

                                    <div className="prod-description-text">
                                        <p> 
                                        Lorem Ipsum is simply dummy text of the printing and
                                        typesetting industry. Lorem Ipsum has been the industry's
                                        Lorem Ipsum is simply dummy text of the printing and
                                        typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever
                                        since the  1500s, </p>

                                        <div className="price-text">
                                         <h3 className="price-grey"> $75 </h3>
                                         <h3 className="price-black"> $55 </h3>
                                        </div>

                                        <div className="cart-number-div">
                                            <button onClick={handleDecrement}>-</button>
                                                <p> {count} </p>
                                            <button onClick={handleIncrement}>+</button>
                                        </div>

                                        <div className="cart-buy-btn">
                                            <button className="buy-btn"> Add to Cart </button>
                                            <button className="buy-btn"> Buy </button>
                                        </div>
                                    </div>

                                    <div className="product-details-text">
                                        <h4> Product Details</h4>
                                        <ul>
                                            <li> Product Code: 441104389016 </li>
                                            <li>Men's Tshirts </li>
                                            <li> Slim Fit </li>
                                            <li> Machine wash cold </li>
                                            <li> Polyester blend </li>                                        
                                        
                                        </ul>
                                    </div>
                           </div>
                        </div>
                
                    </Row>
                
              
                </Container>
            </section>

            <section className="blogs-section blogs-main pt-0"> 
                <Container>
                    <Row>
                        <Col md="12" xs="12">
                            <div className="section-title text-center">
                                <h3 className="text-left">Related Products </h3>
                            </div> {/* section title */}
                        </Col>
                    </Row>

                    <Row>
                        <div className="col-lg-4 col-md-6 col-sm-6">
                            <div className="single-work text-center mt-30 related-prod">
                                <div className="work-image">
                                <img src="https://images.pexels.com/photos/1082528/pexels-photo-1082528.jpeg?auto=compress&cs=tinysrgb&dpr=2&h=650&w=940" alt="work" />
                                </div>
                                <div className="work-overlay">
                                <div className="work-content">
                                    <h3 className="work-title">Product Design</h3>
                                    <ul>
                                        <li><a className="image-popup" href="assets/images/work/w-6.jpg"><i className="lni-cart" /></a></li>
                                        <li><Link to="/shop-details"><i className="lni-eye" /></Link></li>
                                    </ul>
                                </div>
                                </div>
                                <div className="work-overlay-price">
                                    <p> $60.00 </p>
                                </div>  
                            </div> {/* single work */}
                        </div>
                        
                        <div className="col-lg-4 col-md-6 col-sm-6">
                            <div className="single-work text-center mt-30 related-prod">
                                <div className="work-image">
                                <img src="https://images.pexels.com/photos/45982/pexels-photo-45982.jpeg?auto=compress&cs=tinysrgb&dpr=2&h=650&w=940" alt="work" />
                                </div>
                                <div className="work-overlay">
                                <div className="work-content">
                                    <h3 className="work-title">Product Design</h3>
                                    <ul>
                                    <li><a className="image-popup" href="assets/images/work/w-6.jpg"><i className="lni-cart" /></a></li>
                                    <li><Link to="/shop-details"><i className="lni-eye" /></Link></li>
                                    </ul>
                                </div>
                                </div>
                                <div className="work-overlay-price">
                                    <p> $60.00 </p>
                                </div>  
                            </div> {/* single work */}
                        </div>

                        <div className="col-lg-4 col-md-6 col-sm-6">
                            <div className="single-work text-center mt-30 related-prod">
                                <div className="work-image">
                                <img src="https://images.pexels.com/photos/1082528/pexels-photo-1082528.jpeg?auto=compress&cs=tinysrgb&dpr=2&h=650&w=940" alt="work" />
                                </div>
                                <div className="work-overlay">
                                <div className="work-content">
                                    <h3 className="work-title">Product Design</h3>
                                    <ul>
                                    <li><a className="image-popup" href="assets/images/work/w-6.jpg"><i className="lni-cart" /></a></li>
                                    <li><Link to="/shop-details"><i className="lni-eye" /></Link></li>
                                    </ul>
                                </div>
                                </div>
                                <div className="work-overlay-price">
                                    <p> $60.00 </p>
                                </div>  
                            </div> {/* single work */}
                        </div>
                
                    </Row>
                
              
                </Container>
            </section>

            {/*====== FOOTER PART START ======*/}
                <Footer/>
            {/*====== FOOTER PART END ======*/}
         
        </>
    );
}


export default ProductDetails