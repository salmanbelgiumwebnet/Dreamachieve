import React,{useState} from "react";
import { Col, Container, Row } from "react-bootstrap";
import Header from "../navbar/Header";
import { Link } from "react-router-dom";
import Footer from "../footer/Footer";
import { Tab, Tabs, TabList, TabPanel } from 'react-tabs';
import 'react-tabs/style/react-tabs.css';
import ModalVideo from 'react-modal-video'
import ContentLoader, { Facebook } from 'react-content-loader'

function BlogsDetails(props){
    const [isOpen, setOpen] = useState(false)
    return(

        <>
      
            {/*====== HEADER PART START ======*/}
                <Header/>
            {/*====== HEADER PART ENDS ======*/}

            {/*====== banner PART start ======*/}
            <section className="hero-banner-section">
                <Container>
                    <Row>
                        <Col md="12" xs="12">
                            <div className="hero-content">
                                <div className="cd-main"> 
                                    <h5> Blogs Details </h5> 
                                    <ul> 
                                        <li>   <Link to="/" className=""> Home </Link> </li>
                                        <li> <Link to="/blogs" className="active"> blogs details </Link>  </li>
                                      </ul>
                                </div>
                                
                            </div>
                        </Col>
                    </Row>
                </Container>
            </section>
            {/*====== Banner PART End ======*/}

            {/*====== BLOG PART START ======*/}
            <section className="blogs-section blogs-main"> 
                <Container>
                  <Row>

                    <Col md="8">
                    {/* <div class="post-thumb">
                      <img src="assets/images/blog/blog10.jpg" alt="blog" />
                      <div class="post-date">
                          <span>22</span>
                          <span>dec</span>
                      </div>
                  </div> */}



                  <div className="post-item details-post">
                      <div className="post-thumb">
                        <img src="assets/images/blog/blog10.jpg" alt="blog" />
                        <div className="post-date">
                          <span>22</span>
                          <span>dec</span>
                        </div>
                      </div>
                      <div className="post-content">
                        <h4 className="title">
                          Phasellus velit sapien placerat magn iger.
                        </h4>
                        <p>Dolor semper amet, sed phasellus, leo velit quis cras vitae ipsum auctoet maecenas
                          ultrices rhoncus. A tellus vel dis. Magna ad facilisi vestibusattis imperdiet amet
                          ultricies eu, hac egestas ante amet dis duVeeger, tellus ac proin faucibus morbi eraolor
                          semper amet, sed phasellus, lvelit qucras vitae ipsum auctor, et maecenas ultrices
                          rhoncus. A tellus vdis. Magna ad facilisi vestibulum, sagittis imperdiet amet ultricies
                          eu, hac egestas ante amet dis dui. Velit integer, tellus ac proin faucibus morbi erat,
                          enimtrices odio, scelerisque in accumsan. Id penatibus, tempor lectus mi phasellus massa
                          ac, adipiscing purus, tortor sodales ut sed feugiat ipsum, porttitor mauris est
                          eleifend.pede dictum, porttitor magna diam fusce mauris erat, id nunc maecenas massa
                          aenean.</p>
                  
                      </div>
                    </div>
                    </Col>



                    <div className="col-lg-4">
        <aside className="sidebar">
          
          <div className="widget widget-category">
            <div className="widget-header">
              <h5 className="title">Other Blogs</h5>
            </div>
            <ul>
              <li><Link to="blogs">Lorem ipsum<span className="amount">25</span></Link></li>
              <li><Link to="blogs">Lorem ipsum<span className="amount">25</span></Link></li>
              <li><Link to="blogs">Lorem ipsum<span className="amount">25</span></Link></li>
              <li><Link to="blogs">Lorem ipsum<span className="amount">25</span></Link></li>
              <li><Link to="blogs">Lorem ipsum<span className="amount">25</span></Link></li>
              <li><Link to="blogs">Lorem ipsum<span className="amount">25</span></Link></li>
            </ul>
          </div>
    
        </aside>
      </div>



                  </Row>



                 
                
                </Container>
            </section>

            {/*====== BLOG PART ENDS ======*/}

            {/*====== FOOTER PART START ======*/}
                <Footer/>
            {/*====== FOOTER PART END ======*/}

           
        </>
    );
}




export default BlogsDetails