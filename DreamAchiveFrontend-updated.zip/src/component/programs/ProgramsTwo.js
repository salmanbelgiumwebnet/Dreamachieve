import React,{useState} from "react";
import { Col, Container, Row } from "react-bootstrap";
import Header from "../navbar/Header";
import { Link } from "react-router-dom";
import Footer from "../footer/Footer";
import { Tab, Tabs, TabList, TabPanel } from 'react-tabs';
import 'react-tabs/style/react-tabs.css';
import ModalVideo from 'react-modal-video'
import ContentLoader, { Facebook } from 'react-content-loader'

function ProgramsTwo(props){
    const [isOpen, setOpen] = useState(false)
    return(

        <>
      
            {/*====== HEADER PART START ======*/}
                <Header/>
            {/*====== HEADER PART ENDS ======*/}

            {/*====== banner PART start ======*/}
            <section className="hero-banner-section">
                <Container>
                    <Row>
                        <Col md="12" xs="12">
                            <div className="hero-content">
                                <div className="cd-main"> 
                                    <h5> Programs </h5> 
                                    <ul> 
                                        <li> <Link to="/" className=""> Home </Link> </li>
                                        <li> <Link to="/programs" className="active"> programs </Link>  </li>
                                      </ul>
                                </div>
                                
                            </div>
                        </Col>
                    </Row>
                </Container>
            </section>
            {/*====== Banner PART End ======*/}

            {/*====== BLOG PART START ======*/}
            <section className="blogs-section blogs-main"> 
                <Container>
                    <Row>
                        <Col md="12" xs="12">
                           <div className="blogs-title cate-m-title">
                                <h3 className="title2"> Explore By  <strong> Category  </strong></h3>
                            </div>
                        </Col>
                    </Row>

                    <Row>
                        <Col lg="3" md="4" xs="12">
                            <div className="cate-box chat-v2">
                                <div className="cate-img">
                                    <img src="assets/images/events.jpg" />
                                </div>
                                <div className="cate-content">
                                    <h6>  <Link to="/programs"> Clubes </Link> </h6>
                                    <p> Lorem ipsum dollar siet ameat dummy text. </p>
                                    <div className="text-left">
                                        <button className="cate-btn"> <img src="assets/images/arrow-right.png" /> </button>
                                    </div>
                                </div>
                            </div>
                        </Col>
                    </Row>
                

                </Container>
            </section>

            {/*====== BLOG PART ENDS ======*/}

            {/*====== FOOTER PART START ======*/}
                <Footer/>
            {/*====== FOOTER PART END ======*/}

           
        </>
    );
}




export default ProgramsTwo