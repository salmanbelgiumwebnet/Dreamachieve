import React,{useState} from "react";
import { Col, Container, Row } from "react-bootstrap";
import Header from "../navbar/Header";
import { Link } from "react-router-dom";
import Footer from "../footer/Footer";
import { Tab, Tabs, TabList, TabPanel } from 'react-tabs';
import 'react-tabs/style/react-tabs.css';
import ModalVideo from 'react-modal-video'
import ContentLoader, { Facebook } from 'react-content-loader'

function Programs(props){
    const [isOpen, setOpen] = useState(false)
    return(

        <>
      
            {/*====== HEADER PART START ======*/}
                <Header/>
            {/*====== HEADER PART ENDS ======*/}

            {/*====== banner PART start ======*/}
            <section className="hero-banner-section">
                <Container>
                    <Row>
                        <Col md="12" xs="12">
                            <div className="hero-content">
                                <div className="cd-main"> 
                                    <h5> Programs </h5> 
                                    <ul> 
                                        <li> <Link to="/" className=""> Home </Link> </li>
                                        <li> <Link to="/programs" className="active"> programs </Link>  </li>
                                      </ul>
                                </div>
                                
                            </div>
                        </Col>
                    </Row>
                </Container>
            </section>
            {/*====== Banner PART End ======*/}

            {/*====== BLOG PART START ======*/}
            <section className="blogs-section blogs-main"> 
                <Container>
                    <Row>
                        <Col md="12" xs="12">
                           <div className="blogs-title cate-m-title">
                                <h3 className="title2"> Explore By  <strong> Category  </strong></h3>
                            </div>
                        </Col>
                    </Row>

                    <Row>
                        <Col lg="3" md="4" xs="12">
                            <div className="cate-box">
                                <div className="cate-icn">
                                 <i class="fas fa-basketball-ball"></i>
                                </div>
                                <div className="cate-content">
                                    <h6>  <Link to="/courses-video"> Clubes </Link> </h6>
                                    <p> Lorem ipsum dollar siet ameat dummy text. </p>
                                    <div className="text-left">
                                        <button className="cate-btn"> <Link to="/courses-video"> <img src="assets/images/arrow-right.png" /> </Link> </button>
                                    </div>
                                </div>
                            </div>
                        </Col>
                        <Col lg="3" md="4" xs="12">
                            <div className="cate-box">
                                <div className="cate-icn">
                                <i class="fas fa-swimmer"></i>
                                </div>
                                <div className="cate-content">
                                    <h6>  <Link to="/courses-video"> Atleta  </Link> </h6>
                                    <p> Lorem ipsum dollar siet ameat dummy text. </p>
                                    <div className="text-left">
                                        <button className="cate-btn"> <Link to="/courses-video"> <img src="assets/images/arrow-right.png" /> </Link> </button>
                                    </div>
                                </div>
                            </div>
                        </Col>
                        <Col lg="3" md="4" xs="12">
                            <div className="cate-box">
                                <div className="cate-icn">
                                <i class="fas fa-walking"></i>
                                </div>
                                <div className="cate-content">
                                    <h6>  <Link to="/courses-video"> Treinador  </Link> </h6>
                                    <p> Lorem ipsum dollar siet ameat dummy text. </p>
                                    <div className="text-left">
                                        <button className="cate-btn"> <Link to="/courses-video"> <img src="assets/images/arrow-right.png" /> </Link> </button>
                                    </div>
                                </div>
                            </div>
                        </Col>
                        <Col lg="3" md="4" xs="12">
                            <div className="cate-box">
                                <div className="cate-icn">
                                <i class="far fa-address-card"></i>
                                </div>
                                <div className="cate-content">
                                    <h6>  <Link to="/courses-video"> Carreira  </Link> </h6>
                                    <p> Lorem ipsum dollar siet ameat dummy text. </p>
                                    <div className="text-left">
                                        <button className="cate-btn"> <Link to="/courses-video"> <img src="assets/images/arrow-right.png" /> </Link> </button>
                                    </div>
                                </div>
                            </div>
                        </Col>

                        <Col lg="3" md="4" xs="12">
                            <div className="cate-box">
                                <div className="cate-icn">
                                <i class="far fa-building"></i>
                                </div>
                                <div className="cate-content">
                                    <h6>  <Link to="/courses-video"> Empresas </Link> </h6>
                                    <p> Lorem ipsum dollar siet ameat dummy text. </p>
                                    <div className="text-left">
                                        <button className="cate-btn"> <Link to="/courses-video"> <img src="assets/images/arrow-right.png" /> </Link> </button>
                                    </div>
                                </div>
                            </div>
                        </Col>

                        <Col lg="3" md="4" xs="12">
                            <div className="cate-box">
                                <div className="cate-icn">
                                <i class="fas fa-running"></i>
                                </div>
                                <div className="cate-content">
                                    <h6>  <Link to="/courses-video"> Mentoria Psicólogo </Link> </h6>
                                    <p> Lorem ipsum dollar siet ameat dummy text. </p>
                                    <div className="text-left">
                                        <button className="cate-btn"> <Link to="/courses-video"> <img src="assets/images/arrow-right.png" /> </Link> </button>
                                    </div>
                                </div>
                            </div>
                        </Col>

                        <Col lg="3" md="4" xs="12">
                            <div className="cate-box">
                                <div className="cate-icn">
                                <i class="far fa-window-restore"></i>
                                </div>
                                <div className="cate-content">
                                    <h6>  <Link to="/courses-video"> Desenvolvimento Pessoal </Link> </h6>
                                    <p> Lorem ipsum dollar siet ameat dummy text. </p>
                                    <div className="text-left">
                                        <button className="cate-btn"> <Link to="/courses-video"> <img src="assets/images/arrow-right.png" /> </Link> </button>
                                   </div>
                                </div>
                            </div>
                        </Col>

                        <Col lg="3" md="4" xs="12">
                            <div className="cate-box">
                                <div className="cate-icn">
                                <i class="fas fa-brain"></i>
                                </div>
                                <div className="cate-content">
                                    <h6> <Link to="/courses-video"> Acompanhamento Psicológico </Link>  </h6>
                                    <p> Lorem ipsum dollar siet ameat dummy text. </p>
                                    <div className="text-left">
                                         <button className="cate-btn"> <Link to="/courses-video"> <img src="assets/images/arrow-right.png" /> </Link> </button>
                                    </div>
                                </div>
                            </div>
                        </Col>
                    </Row>
                

                </Container>
            </section>

            {/*====== BLOG PART ENDS ======*/}

            {/*====== FOOTER PART START ======*/}
                <Footer/>
            {/*====== FOOTER PART END ======*/}

           
        </>
    );
}




export default Programs