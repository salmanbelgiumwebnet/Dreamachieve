import React, { useState, useEffect } from "react";
import { Col, Container, Row,Modal } from "react-bootstrap";
import Header from "../navbar/Header";
import { Link } from "react-router-dom";
import Footer from "../footer/Footer";
import { Tab, Tabs, TabList, TabPanel } from 'react-tabs';
import 'react-tabs/style/react-tabs.css';
import ModalVideo from 'react-modal-video'
import ContentLoader, { Facebook } from 'react-content-loader'

import environment from '../base/baseUrl'
import axios from 'axios';
import Swal from "sweetalert2";

function Video(props){
    const [lgShow, setLgShow] = useState(false);
    var BASE_URL = environment.BASE_URL;

    const [isOpen, setOpen] = useState(false)
    const [videoPage, setVideoPage] = useState([])
    const [videoCategory, setVideoCategory] = useState([])
    const [video, setVideo] = useState([])

    useEffect(() => {
        axios
            .get(BASE_URL + '/getlayout')
            .then(res => {
                setVideoPage(res.data[0])
                console.clear();
                console.log(res.data[0])
            }).catch(err => {
                console.log(err)
            })
        axios
            .get(BASE_URL + '/videocategories')
            .then(res => {
                setVideoCategory(res.data)
                console.log(res.data)
            }).catch(err => {
                console.log(err)
            })
        axios
            .get(BASE_URL + '/videos')
            .then(res => {
                setVideo(res.data)
                console.log(res.data)
            }).catch(err => {
                console.log(err)
            })
    }, [])
    
    
    return(

        <>
      
            {/*====== HEADER PART START ======*/}
                <Header/>
            {/*====== HEADER PART ENDS ======*/}

            {/*====== banner PART start ======*/}
            <section className="hero-banner-section">
                <Container>
                    <Row>
                        <Col md="12" xs="12">
                            <div className="hero-content">
                                <div className="cd-main"> 
                                    <h5> Video </h5> 
                                    <ul> 
                                        <li>   <Link to="/" className=""> Home </Link> </li>
                                        <li> <Link to="/video" className="active"> Video </Link>  </li>
                                      </ul>
                                </div>
                                
                            </div>
                        </Col>
                    </Row>
                </Container>
            </section>
            {/*====== Banner PART End ======*/}

            {/*====== BLOG PART START ======*/}
            <section className="blogs-section blogs-main"> 
                <Container>
                    <Row>
                        <Col md="12" xs="12">
                           <div className="blogs-title vid-title">
                                <h3 className="title2">THE BEST Nádia Tavares  <span> VIDEOS </span> </h3>
                                <p> Lorem Ipsum is simply dummy text of the printing and typesetting industry. </p>
                    
                           </div>
                        </Col>
                    </Row>

                    <Row>
                        <Col md="4" xs="12">
                            <div className="video-box ">
                                <div className="video-btn-icn" onClick={() => setLgShow(true)}>
                                <i class="fa fa-play" aria-hidden="true"></i>
                                </div>
                                <div className="video-text">
                                    <h6> Lorem ipsum dollar </h6>
                                    <p> By lorem ipsum </p>
                                </div>
                            </div>
                        </Col>

                        <Col md="4" xs="12">
                            <div className="video-box ">
                                <div className="video-btn-icn" onClick={()=> setOpen(true)}>
                                <i class="fa fa-play" aria-hidden="true"></i>
                                </div>
                                <div className="video-text">
                                    <h6> Lorem ipsum dollar </h6>
                                    <p> By lorem ipsum </p>
                                </div>
                            </div>
                        </Col>

                        <Col md="4" xs="12">
                            <div className="video-box ">
                                <div className="video-btn-icn" onClick={()=> setOpen(true)}>
                                <i class="fa fa-play" aria-hidden="true"></i>
                                </div>
                                <div className="video-text">
                                    <h6> Lorem ipsum dollar </h6>
                                    <p> By lorem ipsum </p>
                                </div>
                            </div>
                        </Col>

                    </Row>

                </Container>
            </section>

            {/*====== BLOG PART ENDS ======*/}

            {/*====== FOOTER PART START ======*/}
                <Footer/>
            {/*====== FOOTER PART END ======*/}

            <ModalVideo autoplay isOpen={isOpen}  className="modal-main-d" onClose={() => setOpen(false)}>


                          
                           

            </ModalVideo>


            <Modal
                size="lg"
                show={lgShow}
                onHide={() => setLgShow(false)}
                aria-labelledby="example-modal-sizes-title-lg"
                centered
            >
        <Modal.Header closeButton className="modal-div-header">
          {/* <Modal.Title id="example-modal-sizes-title-lg">
           Video
          </Modal.Title> */}
        </Modal.Header>
        <Modal.Body className="modal-body-div">

            <Col md={12}>
                <div className="modal-div">
                    <video className="modal-vid-tag" controls>
                        <source src="assets/big_buck_bunny_720p_1mb.mp4" type="video/mp4" />
                        <source src="movie.ogg" type="video/ogg" />
                        Your browser does not support the video tag.
                    </video>
                </div>
            </Col>

        </Modal.Body>
      </Modal>

        </>
    );
}




export default Video