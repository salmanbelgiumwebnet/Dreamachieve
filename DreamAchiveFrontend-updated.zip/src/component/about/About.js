import React, { useState, useEffect } from "react";
import { Col, Container, Row } from "react-bootstrap";
import Header from "../navbar/Header";
import { Link } from "react-router-dom";
import Footer from "../footer/Footer";
import ModalVideo from 'react-modal-video'


import environment from '../base/baseUrl'
import axios from 'axios';
import Swal from "sweetalert2";

function About(props){

    var BASE_URL = environment.BASE_URL;
    
    const [whatWeProvide, setWhatWeProvide] = useState([])
    const [aboutme, setAboutMe] = useState([])

    useEffect(() => {
        axios
            .get(BASE_URL + '/whatweprovide')
            .then(res => {
                setWhatWeProvide(res.data)
                console.clear();
                console.log(res.data)
            }).catch(err => {
                console.log(err)
            })
    }, [])

    return(

        <>
         
            {/*====== HEADER PART START ======*/}
            <Header/>
            {/*====== HEADER PART ENDS ======*/}

            {/*====== banner PART start ======*/}
            <section className="hero-banner-section">
                <Container>
                    <Row>
                        <Col md="12" xs="12">
                            <div className="hero-content">
                                <div className="cd-main"> 
                                    <h5> About </h5> 
                                    <ul> 
                                        <li>   <Link to="/" className=""> Home </Link> </li>
                                        <li> <Link to="/video" className="active"> About </Link>  </li>
                                      </ul>
                                </div>
                                
                            </div>
                        </Col>
                    </Row>
                </Container>
            </section>
            {/*====== Banner PART End ======*/}
            
            {/*====== About Section One START ======*/}
            <section className="about-section-1"> 
                <Container>
                    <Row>
                        <Col lg="4" md="5" xs="12">
                        <div className="abt-lf-image">
                                <img src="assets/images/about.jpg" />
                        </div>
                        </Col>

                        <Col lg="8" md="7" xs="12">
                            <div className="about-s1-ct-main">
                                <div className="abt-title">
                                    <h2>  Nádia Tavares </h2>
                                </div>
                                <p>  Nádia Tavares is the Founder and CEO of DreamAchieve.She has a degree in Psychology and Specialized in Coaching, Performance and Sports and a former athlete ininternational (100 internationals) and professional basketball in Portugal and Spain.She is the author of two books, Mind7 de Athlete (2018) and Mind7 das Lesões (2019).She has already worked at institutions such as Sporting Clube de Portugal, Sport Lisboa e Benfica and the Portuguese Basketball Federation.She works with athletes, coaches and teams in football, basketball, volleyball, athletics, tennis, paddle, sailing, surfing, rugby, judo, karts, jetski,gymnastics and dance.In addition to sports, she conducts performance development programs in companies, and works one-on-one with CEO's and senior executives.She is a professor in several postgraduate courses, a trainer and speaker in several lectures.“Sport and Companies are constantly combined on numerous topics: In performance to achieve results, in leadership, in communication between team members, in the necessary resilience, in the ability to generate new solutions, and also in terms of personal balance that can generate issues of anxiety, lack of confidence, negative self-talk and low motivation. We are, in both ways, working with people who want to be at their maximum potential, as a team and with a leader.” More about this source text
                            </p>
                
                                {/* <button className="main-btn mt-3"> <Link to="/contact"> Contact us </Link> </button> */}
                            </div>
                        </Col>
                    </Row>


            
                </Container>
            </section>
      
            <section className="about-section-2"> 
                <Container>
                
                    <Row>
                        <Col lg={12}>
                            <div className="about-details-text-d">
                                <h4>  Dream Achieve</h4>
                                <p>   
                                    DreamAchieve is summed up in six keywords: “We work with Psychology and Coaching in Sports and in Companies for Health and Performance”. Since 2016, DreamAchieve has been active in sports with athletes, coaches, teams and sports institutions; both internally and externally in a consultancy plan. More recently, since 2020, he started working in companies, both with lectures and with programs to increase performance and health. We live in an increasingly competitive and volatile world, where what is new today will become obsolete tomorrow. In this way, the sciences responsible for the development of performance, such as Psychology and Coaching, begin to gain a decisive role in all contexts in which competition is present. On the other hand, this search for ideal performance has taken health out of many, both in sports and in companies, opening debates on topics such as Mental Health in Sports and in Companies. If, in order to reach the ideal Performance, sometimes you can lose Health, losing Health we lower the Performance levels. In this way, DreamAchieve works on the perfect balance between Health and Performance to achieve the best results, maintaining optimal levels of human health, reaching its maximum potential. 
                                </p>
                            </div>
                        </Col>
                    </Row>

                    <Row>
                        <Col lg={12}>
                            <div className="about-details-text-d pb-40">
                                <h4> What we do </h4>
                                <p>
                                Nádia Tavares is the Founder and CEO of DreamAchieve.She has a degree in Psychology and Specialized in Coaching, Performance and Sports and a former athlete ininternational (100 internationals) and professional basketball in Portugal and Spain.She is the author of two books, Mind7 de Athlete (2018) and Mind7 das Lesões (2019).She has already worked at institutions such as Sporting Clube de Portugal, Sport Lisboa e Benfica and the Portuguese Basketball Federation.She works with athletes, coaches and teams in football, basketball, volleyball, athletics, tennis, paddle, sailing, surfing, rugby, judo, karts, jetski,gymnastics and dance.In addition to sports, she conducts performance development programs in companies, and works one-on-one with CEO's and senior executives.She is a professor in several postgraduate courses, a trainer and speaker in several lectures.“Sport and Companies are constantly combined on numerous topics: In performance to achieve results, in leadership, in communication between team members, in the necessary resilience, in the ability to generate new solutions, and also in terms of personal balance that can generate issues of anxiety, lack of confidence, negative self-talk and low motivation. We are, in both ways, working with people who want to be at their maximum potential, as a team and with a leader.” More about this source text
                                </p>
                            </div>
                        </Col>
                    </Row>
              
                </Container>
            </section>

            {/*====== About Section Two START ======*/}    
            <section className="about-section-two d-none">
            <Container fluid> 
                <Row>
                   
                    <Col lg="6 pd-0" xs="12">
                         <div className="abt-s2-img">
                            <img src="assets/images/about-22.jpg" />
                         </div>
                    </Col>

                    <Col lg="6 pd-0" xs="12">
                         <div className="abt-s2-content">
                             <div className="abt-2-title">
                                 <h4> Lorem ipsum dollar. </h4>
                                 <p> Lorem Ipsum is simply dummy text of the printing and typesetting industry. </p>
                             </div>


                            <div className="sction-two-step">
                                <div className="step-count-title">
                                    <h5 className="count-text"> 01 </h5>
                                    <h6 className="step-title"> Lorem ipsum dollar site ameat </h6>
                                </div>
                                <p> Lorem Ipsum is simply dummy text of the printing and typesetting industry.
                                    Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, </p>
                            </div>

                            <div className="sction-two-step">
                                <div className="step-count-title">
                                    <h5 className="count-text"> 02 </h5>
                                    <h6 className="step-title"> Lorem ipsum dollar site ameat </h6>
                                </div>
                                <p> Lorem Ipsum is simply dummy text of the printing and typesetting industry.
                                    Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, </p>
                            </div>


                            <div className="sction-two-step">
                                <div className="step-count-title">
                                    <h5 className="count-text"> 03 </h5>
                                    <h6 className="step-title"> Lorem ipsum dollar site ameat </h6>
                                </div>
                                <p> Lorem Ipsum is simply dummy text of the printing and typesetting industry.
                                    Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, </p>
                            </div>

                         </div>

                    </Col>
                   
                </Row>
                </Container>
            </section>
            {/*====== About Section One End ======*/}

             {/*====== What we do section START ======*/}
             <section className="blogs-section d-none"> 
                <Container>
                    <Row>
                        <Col md="12" xs="12">
                           <div className="blogs-title">
                                <h2> What We Do </h2>
                                <p> Lorem Ipsum is simply dummy text of the printing and typesetting industry. </p>
                           </div>
                        </Col>
                    </Row>

                    <Row>
                        <Col md="4" xs="12">
                            <div className="blog-box what-we-box">
                                <div className="blog-img what-we-img">
                                    <img src="https://via.placeholder.com/400x280" />
                                </div>
                                <div className="blog-text-d what-we-text">
                                   <Link to=""> <h5>Lorem ipsum  </h5> </Link> 
                                    <p>
                                    Lorem Ipsum is simply dummy text of the printing
                                    and typesetting industry  Lorem Ipsum is simply dummy text of the printing and
                                    </p>
                                    <button className="blog-btn what-we-btn"> <i class="fas fa-long-arrow-alt-right"></i> </button>
                                </div>  
                            </div>
                        </Col>

                        <Col md="4" xs="12">
                            <div className="blog-box what-we-box">
                                <div className="blog-img what-we-img">
                                    <img src="https://via.placeholder.com/400x280" />
                                </div>
                                <div className="blog-text-d what-we-text">
                                   <Link to=""> <h5>Lorem ipsum  </h5> </Link> 
                                    <p>
                                    Lorem Ipsum is simply dummy text of the printing
                                    and typesetting industry  Lorem Ipsum is simply dummy text of the printing and
                                    </p>
                                    <button className="blog-btn what-we-btn"> <i class="fas fa-long-arrow-alt-right"></i> </button>
                                </div>  
                            </div>
                        </Col>
                        <Col md="4" xs="12">
                            <div className="blog-box what-we-box">
                                <div className="blog-img what-we-img">
                                    <img src="https://via.placeholder.com/400x280" />
                                </div>
                                <div className="blog-text-d what-we-text">
                                   <Link to=""> <h5>Lorem ipsum  </h5> </Link> 
                                    <p>
                                    Lorem Ipsum is simply dummy text of the printing
                                    and typesetting industry  Lorem Ipsum is simply dummy text of the printing and
                                    </p>
                                    <button className="blog-btn what-we-btn"> <i class="fas fa-long-arrow-alt-right"></i> </button>
                                </div>  
                            </div>
                        </Col>

                        <Col md="4" xs="12">
                            <div className="blog-box what-we-box">
                                <div className="blog-img what-we-img">
                                    <img src="https://via.placeholder.com/400x280" />
                                </div>
                                <div className="blog-text-d what-we-text">
                                   <Link to=""> <h5>Lorem ipsum  </h5> </Link> 
                                    <p>
                                    Lorem Ipsum is simply dummy text of the printing
                                    and typesetting industry  Lorem Ipsum is simply dummy text of the printing and
                                    </p>
                                    <button className="blog-btn what-we-btn"> <i class="fas fa-long-arrow-alt-right"></i> </button>
                                </div>  
                            </div>
                        </Col>

                        <Col md="4" xs="12">
                            <div className="blog-box what-we-box">
                                <div className="blog-img what-we-img">
                                    <img src="https://via.placeholder.com/400x280" />
                                </div>
                                <div className="blog-text-d what-we-text">
                                   <Link to=""> <h5>Lorem ipsum  </h5> </Link> 
                                    <p>
                                    Lorem Ipsum is simply dummy text of the printing
                                    and typesetting industry  Lorem Ipsum is simply dummy text of the printing and
                                    </p>
                                    <button className="blog-btn what-we-btn"> <i class="fas fa-long-arrow-alt-right"></i> </button>
                                </div>  
                            </div>
                        </Col>
                        <Col md="4" xs="12">
                            <div className="blog-box what-we-box">
                                <div className="blog-img what-we-img">
                                    <img src="https://via.placeholder.com/400x280" />
                                </div>
                                <div className="blog-text-d what-we-text">
                                   <Link to=""> <h5>Lorem ipsum  </h5> </Link> 
                                    <p>
                                    Lorem Ipsum is simply dummy text of the printing
                                    and typesetting industry  Lorem Ipsum is simply dummy text of the printing and
                                    </p>
                                    <button className="blog-btn what-we-btn"> <i class="fas fa-long-arrow-alt-right"></i> </button>
                                </div>  
                            </div>
                        </Col>
                        
                    </Row>

                
                </Container>
            </section>
            {/*====== What we do section END ======*/}


            
            
            {/*====== FOOTER PART START ======*/}
                <Footer/>
            {/*====== FOOTER PART END ======*/}


        </>
        );
    }




export default About