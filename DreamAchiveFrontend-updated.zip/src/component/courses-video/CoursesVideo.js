import React,{useState} from "react";
import { Col, Container, Row } from "react-bootstrap";
import Header from "../navbar/Header";
import { Link } from "react-router-dom";
import Footer from "../footer/Footer";
import { Tab, Tabs, TabList, TabPanel } from 'react-tabs';
import 'react-tabs/style/react-tabs.css';
import ModalVideo from 'react-modal-video'
import ContentLoader, { Facebook } from 'react-content-loader'

function CoursesVideo(props){
    const [isOpen, setOpen] = useState(false)
    return(
        <>
            {/*====== HEADER PART START ======*/}
                <Header/>
            {/*====== HEADER PART ENDS ======*/}

            {/*====== banner PART start ======*/}
            <section className="hero-banner-section">
                <Container>
                    <Row>
                        <Col md="12" xs="12">
                            <div className="hero-content">
                                <div className="cd-main"> 
                                    <h5> Courses Video </h5> 
                                    <ul> 
                                        <li> <Link to="/" className=""> Home </Link> </li>
                                        <li> <Link to="/courses-video" className="active"> Courses Video </Link>  </li>
                                      </ul>
                                </div>
                                
                            </div>
                        </Col>
                    </Row>
                </Container>
            </section>
            {/*====== Banner PART End ======*/}

            {/*====== BLOG PART START ======*/}
            <section className="blogs-section blogs-main"> 
                <Container>
                    <Row>
                        <Col md="12" xs="12">
                           <div className="blogs-title cate-m-title">
                                <h3 className="title2"> Clubes</h3>
                            </div>
                        </Col>
                    </Row>

                    <Row>
                        <Col lg="3" md="4" xs="12">
                            <div className="cate-box chat-v2">
                                <div className="cate-img">
                                    <img src="assets/images/events.jpg" />
                                </div>
                                <div className="cate-content">
                                    
                                    <h6>  <Link to="/courses-all-video"> Sporting Season </Link> </h6>
                                    <div className="name-rating">
                                    <div className="">
                                        <p> <strong>  Ben Colefax  </strong> </p>
                                    </div>
                                    <div className="cours-rating">
                                        <p>  3.5  </p>
                                    </div>
                                  
                                    </div>
                                    <p> lorem ipsum dollar site ameat dummy text lorem ipsum dollar site ameat dummy text. </p>
                                  
                                    <div className="text-left">
                                        <button className="cate-btn">
                                            <Link to="/courses-all-video"> <img src="assets/images/arrow-right.png" /> 
                                            </Link>
                                        </button>
                                    </div>
                                </div>
                                <div className="courses-vid-tag">
                                    <p> Free </p>
                                </div>
                            </div>
                        </Col>

                        <Col lg="3" md="4" xs="12">
                            <div className="cate-box chat-v2">
                                <div className="cate-img">
                                    <img src="assets/images/events.jpg" />
                                </div>
                                <div className="cate-content">
                                    
                                    <h6>  <Link to="/courses-all-video"> Workshop and Lectures </Link> </h6>
                                    <div className="name-rating">
                                    <div className="">
                                        <p> <strong>  Ben Colefax  </strong> </p>
                                    </div>
                                    <div className="cours-rating">
                                        <p>  3.5  </p>
                                    </div>
                                  
                                    </div>
                                    <p> lorem ipsum dollar site ameat dummy text lorem ipsum dollar site ameat dummy text. </p>
                                  
                                    <div className="text-left">
                                        <button className="cate-btn">
                                            <Link to="/courses-all-video"> <img src="assets/images/arrow-right.png" /> 
                                            </Link>
                                        </button>
                                    </div>
                                </div>
                                <div className="courses-vid-tag">
                                    <p> Free </p>
                                </div>
                            </div>
                        </Col>
                    </Row>
                

                </Container>
            </section>

            {/*====== BLOG PART ENDS ======*/}

            {/*====== FOOTER PART START ======*/}
                <Footer/>
            {/*====== FOOTER PART END ======*/}

           
        </>
    );
}




export default CoursesVideo