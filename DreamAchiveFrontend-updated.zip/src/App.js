import React, {useState,useEffect} from 'react';
import { Route, Switch } from 'react-router-dom';
import GoToTop from './component/go-to-top/GotoTop';
import Routes from './Routes';


function App() {
  const [isLoading, setLoading] = useState(true);

  function fakeRequest() {
    return new Promise(resolve => setTimeout(() => resolve(), 1500));
  }
  useEffect(() => {
    fakeRequest().then(() => {
      const el = document.querySelector(".loader-container");
      if (el) {
        el.remove();
        setLoading(!isLoading);
      }
    });
  }, []);

  if (isLoading) {
    return null;
  } 
  return (
    <>
      <Routes/>
      <GoToTop/>
    </>
  );
}



export default App;


